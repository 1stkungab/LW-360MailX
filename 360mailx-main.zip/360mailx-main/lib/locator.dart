import 'package:get_it/get_it.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/router.config.dart';
import 'package:loveworld_mail/services/account.repository.dart';
import 'package:loveworld_mail/services/toast.service.dart';


final GetIt locator = GetIt.instance;
void setupLocator() {
  locator.registerLazySingleton<AccountRepository>(() => AccountRepository());
  locator.registerLazySingleton<ToastService>(() => ToastService());
  locator.registerSingleton<GoRouter>(AppRouter().router);

}
