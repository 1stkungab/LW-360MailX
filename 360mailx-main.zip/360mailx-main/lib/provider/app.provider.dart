import 'package:flutter/material.dart';
import 'package:loveworld_mail/constant/otpstate.dart';


class AppProvider extends ChangeNotifier {

OTPSTATEENUM? _otpState;
OTPSTATEENUM? get otpState => _otpState;

setOTPState(newstate){
  _otpState = newstate;
  notifyListeners();
}
}



