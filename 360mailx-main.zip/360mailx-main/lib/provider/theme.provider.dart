import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:loveworld_mail/config/color.config.dart';

class ThemeClass {
  static final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);
  static final ValueNotifier<int> counterNotifier = ValueNotifier(0);

  static ThemeData lightTheme = ThemeData(
    fontFamily: 'Poppins',
    scaffoldBackgroundColor: AppColors.bgColor,
    secondaryHeaderColor: const Color(0xFFe6e7e8),
    hintColor: Colors.black.withOpacity(0.1),
    shadowColor: AppColors.shadowW,
    primaryColor: AppColors.primary,
    primaryColorLight: const Color(0xFFC9DFE3), //this affect the textinput and active prefix color
    primaryColorDark: AppColors.primaryDark,
    splashColor: Colors.transparent,
    appBarTheme: AppBarTheme(
      backgroundColor: AppColors.bgColor,
      foregroundColor: Colors.transparent,
      elevation: 0,
      iconTheme: const IconThemeData(color: Colors.black),
      toolbarTextStyle: const TextStyle(
        color: Colors.black87
      ),
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
    ),
    brightness: Brightness.light,
    colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary, primary: AppColors.primary).copyWith(surface: AppColors.scaffoldWOff),
  
  );

  static ThemeData darkTheme = ThemeData(
    fontFamily: 'Poppins',
    canvasColor: const Color(0xFF101A21),
    scaffoldBackgroundColor: AppColors.scaffoldD,
    shadowColor: AppColors.shadowD,
    secondaryHeaderColor: AppColors.blacklight, //white equ
    primaryColorDark: const Color(0xFFF2F2F2),
    primaryColor: AppColors.primary,
    hintColor: const Color(0xffA3A3A3),

    splashColor: Colors.transparent,
    appBarTheme:  AppBarTheme(
      backgroundColor: Colors.transparent,
      foregroundColor: Colors.transparent,
      elevation: 0,
      toolbarTextStyle: const TextStyle(
        color: Color(0xfff2f2f2),
      ),
      iconTheme: IconThemeData(color: AppColors.white),
      systemOverlayStyle: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
    ),
    brightness: Brightness.dark,
    colorScheme: ColorScheme.fromSeed(brightness: Brightness.dark, seedColor: AppColors.primary, primary: AppColors.primary).copyWith(surface: AppColors.scaffoldDOff),
  );
}

Color getColor(Set<WidgetState> states) {
  const Set<WidgetState> interactiveStates = <WidgetState>{
    WidgetState.pressed,
    WidgetState.hovered,
    WidgetState.focused,
  };
  if (states.any(interactiveStates.contains)) {
    return Colors.blue;
  }
  return Colors.red;
}
