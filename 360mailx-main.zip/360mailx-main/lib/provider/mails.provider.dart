import 'dart:developer' as dev;
import 'dart:io';
import 'dart:math';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/constant/constant.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/constant/data/mails.data.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/model/email.model.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/email.repository.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:loveworld_mail/utilities/logger.dart';

class MailsProvider extends ChangeNotifier {
  List<Map<String, dynamic>> data = [];
  List<Map<String, dynamic>> trash = [];
  List<Map<String, dynamic>> starred = [];
  List<EmailAccount> emailaccounts = [];
  List<dynamic> emailfolders = [];
  List<FolderMail> tempFolderMail = [];
  List<FolderMail> staredFolderMail = [];
  List<FolderMail> sentFolderMail = [];
  List<FolderMail> trashFolderMail = [];

  int? activeAccountid;

  bool isLoading = false;
  bool isFetching = false;
  int currentPage = 1;
  bool loadingMailBox = false;

  /*---------------------------PROFILE UPDATE START---------------------------*/

  File? file;
  bool fileSet = false;

  void pickAnyFile() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.any,
      );

      if (result != null) {
        file = File(result.files.single.path!);
        fileSet = true;
        notifyListeners();
      }
    } catch (error) {
      AppLogger().e("Error picking file: $error");
    }
  }

  void removeUpload() {
    file = null;
    fileSet = false;
    notifyListeners();
  }

  bool switching = false;

  /*---------------------------PROFILE UPDATE ENDS---------------------------*/

  selectDifferentAccount(accountIndex) async {
    activeAccountid = accountIndex;
    notifyListeners();
    await fetchFolders(accountIndex);
    notifyListeners();
    locator<ToastService>().showToast('Account Changed Succesfuly');
  }

  Future fetchEmailAccounts() async {
    try {
      Response response = await EmailRepository().accounts();

      if (response.statusCode == 200) {
        var data = response.data['data'];
        emailaccounts = List.generate(
            data.length, (index) => EmailAccount.fromJson(data[index]));

        activeAccountid = emailaccounts.last.id;
        await fetchFolders(emailaccounts.last.id);

        return true;
      } else {
        return false;
      }
    } catch (error) {
      logger.e('error fetching email accounts', error);
      return false;
    }
  }

  Future deleteMailAccount(index, paylaod) async {
    emailaccounts.removeAt(index);
    Response response = await EmailRepository().deleteMailAccount(paylaod);
    if (response.statusCode == 200) {
      locator<ToastService>().showToast("Account Deleted");
    } else {
      locator<ToastService>().showToast("Couldn't delete account");
    }
    notifyListeners();
    return true;
  }

  Future fetchFolders(aid) async {
    try {
      Response response = await EmailRepository().folders({"account_id": aid});

      if (response.statusCode == 200 && response.data != null) {

        logger.e("this is the log------ ${aid} --- ${response.data}");
        emailfolders = response.data;
        if (emailfolders.isNotEmpty) {
          var inboxResponse = await fetchFolderMail(aid, 'INBOX');
          var starredResponse = await fetchFolderStaredMail(aid, 'INBOX');
          var sentResponse = await fetchFolderMail(aid, 'Sent');
          var trashResponse = await fetchFolderMail(aid, 'Trash');

          logger.e("this is the log------ ${aid} --- ${inboxResponse}");

          if (inboxResponse != null) {
            List data = inboxResponse.data['emails'];

            tempFolderMail = List.generate(
                data.length, (int index) => FolderMail.fromJson(data[index]));
          }

          if (starredResponse != null) {
            List data = starredResponse.data['emails'];
            staredFolderMail = List.generate(
                data.length, (int index) => FolderMail.fromJson(data[index]));
          }

          if (sentResponse != null) {
            List data = sentResponse.data['emails'];
            sentFolderMail = List.generate(
                data.length, (int index) => FolderMail.fromJson(data[index]));
          }

          if (trashResponse != null) {
            List data = trashResponse.data['emails'];
            trashFolderMail = List.generate(
                data.length, (int index) => FolderMail.fromJson(data[index]));
          }
        }

        notifyListeners();
        return true;
      } else {
        return false;
      }
    } catch (error) {
      logger.e('error fetching email folders', error);
      return false;
    }
  }

  Future LoadAccountMails(response) async {
    try {
      var data = response.data['account'];
      var aid = data['id'];

      logger.e("this is the log------ ${aid} --- ${data}");

      var inboxResponse = await fetchFolderMail(aid, 'INBOX');
      var starredResponse = await fetchFolderStaredMail(aid, 'INBOX');
      var sentResponse = await fetchFolderMail(aid, 'Sent');
      var trashResponse = await fetchFolderMail(aid, 'Trash');

      if (inboxResponse != null) {
        List data = inboxResponse.data['emails'];
        tempFolderMail = List.generate(
            data.length, (int index) => FolderMail.fromJson(data[index]));
      }

      if (starredResponse != null) {
        List data = starredResponse.data['emails'];
        staredFolderMail = List.generate(
            data.length, (int index) => FolderMail.fromJson(data[index]));
      }

      if (sentResponse != null) {
        List data = sentResponse.data['emails'];
        sentFolderMail = List.generate(
            data.length, (int index) => FolderMail.fromJson(data[index]));
      }

      if (trashResponse != null) {
        List data = trashResponse.data['emails'];
        trashFolderMail = List.generate(
            data.length, (int index) => FolderMail.fromJson(data[index]));
      }
    } catch (error) {
      logger.e('error fetching accounts mails', error);
      return false;
    }
  }

  Future fetchFolderMail(aid, folder) async {
    try {
      Response response = await EmailRepository()
          .folderMails({"account_id": aid, "folder": folder});
      print('--------------- ${response.statusCode}  $folder');

      if (response.statusCode == 200) {
        return response;
      } else {
        return null;
      }
    } catch (error) {
      logger.e('error fetching folder email', error);
      return null;
    }
  }

  Future fetchFolderStaredMail(aid, folder) async {
    try {
      Response response = await EmailRepository()
          .folderStarredMails({"account_id": aid, "folder": folder});
      print('--------------- ${response.statusCode}  STARRED $folder');

      if (response.statusCode == 200) {
        return response;
      } else {
        return null;
      }
    } catch (error) {
      logger.e('error fetching folder email', error);
      return null;
    }
  }

  Future fetchMessageDetails(aid, folder, message_id) async {
    try {
      Response response = await EmailRepository().readMail(
          {"account_id": aid, "folder": folder, "message_id": message_id});
      if (response.statusCode == 200) {
        return response;
      } else {
        return null;
      }
    } catch (error) {
      logger.e('error fetching folder email', error);
      return false;
    }
  }

  FolderMail? selectedMail;
  String mailbody = rendering;
  Map<String, dynamic>? inboxDetails;

  Future readMail(folder, message_id, item) async {
    try {
      selectedMail = item;
      mailbody = rendering;
      notifyListeners();

      locator<GoRouter>().push(AppRoutes.htmlemaildetailspage);

      var response =
          await fetchMessageDetails(activeAccountid, folder, message_id);

      mailbody = response.data['body'];
      inboxDetails = response.data;
      // logger.e("mail body ${response.data['body']}");
      notifyListeners();
    } catch (error) {
      logger.e('error fetching folder email', error);
      return false;
    }
  }

  Future<void> fetchData({bool first = false}) async {
    if (isLoading || isFetching) return;

    if (first) {
      isLoading = true;
    } else {
      isFetching = true;
    }
    notifyListeners();

    await Future.delayed(const Duration(seconds: 2));
    dataz.shuffle(Random());
    List<Map<String, dynamic>> newData = dataz.take(15).toList();

    data.addAll(newData);
    currentPage++;
    if (first) {
      isLoading = false;
    } else {
      isFetching = false;
    }

    notifyListeners();
  }

  void permanentlyDeleteItem(int index, label) async {
    int emailId = trashFolderMail[index].id ?? 1;
    trashFolderMail.removeAt(index);
    notifyListeners();

    Map<String, dynamic> formData = {
      "account_id": activeAccountid,
      "message_id": emailId,
      "folder": label.toString().toUpperCase()
    };

    try {
      Response response = await EmailRepository().permanentDelete(formData);
      logger.e("response ${response} - $formData");
    } catch (e) {
      logger.e("Error deleting mail $e");
    }
  }


    void restore(int index, label) async {
    int emailId = trashFolderMail[index].id ?? 1;
    trashFolderMail.removeAt(index);
    notifyListeners();

    Map<String, dynamic> formData = {
      "account_id": activeAccountid,
      "message_id": emailId,
    };

    try {
      Response response = await EmailRepository().restore(formData);
      logger.e("response ${response} - $formData");
    } catch (e) {
      logger.e("Error deleting mail $e");
    }
  }

  void deleteItem(int index, label) async {
    if (label == 'inbox') {
      trashFolderMail.add(tempFolderMail[index]);
      tempFolderMail.removeAt(index);
    } else if (label == 'sent') {
      trashFolderMail.add(sentFolderMail[index]);
      sentFolderMail.removeAt(index);
    } else if (label == 'trash') {
      trashFolderMail.removeAt(index);
    } else if (label == 'starred') {
      trashFolderMail.add(staredFolderMail[index]);
      staredFolderMail.removeAt(index);
    }
    notifyListeners();

    Map<String, dynamic> formData = {
      "account_id": activeAccountid,
      "message_id": trashFolderMail[trashFolderMail.length - 1].id,
      "folder": label.toString().toUpperCase()
    };

    try {
      Response response = await EmailRepository().trashMail(formData);

      logger.e("response ${response} - $formData");
    } catch (e) {
      logger.e("Error deleting mail $e");
    }
  }

  void starMails(int mailId, String label) async {
    logger.e("message $mailId");

    int selectedIndex = tempFolderMail.indexWhere((mail) => mail.id == mailId);
    int existingIndex =
        staredFolderMail.indexWhere((mail) => mail.id == mailId);

    if (existingIndex >= 0) {
      staredFolderMail.removeAt(existingIndex);
    } else {
      if (selectedIndex >= 0) {
        FolderMail selected = tempFolderMail[selectedIndex];
        staredFolderMail.add(selected);
      }
    }

    notifyListeners();

    try {
      Map<String, dynamic> formData = {
        "account_id": activeAccountid,
        "message_id": mailId,
        "folder": label.toString().toUpperCase()
      };

      Response response = await EmailRepository().starredMail(formData);

      logger.e("response ${response} - $formData");
    } catch (e) {
      logger.e("Error deleting mail $e");
    }
  }

  bool mailsending = false;

  Future sendMail() async {
    Map<String, dynamic> payload = {
      "account_id": "${activeAccountid}",
      "to": toController.text,
      "subject": subjectController.text,
      "body": bodyController.text,
      "cc": ccController.text.split(","),
      "bcc": bccController.text.split(","),
      "attachments": []
    };

    try {
      mailsending = true;
      Response response = await EmailRepository().sendMail(payload);

      if (response.statusCode == 200) {
        locator<ToastService>().showToast("Email sent successfully");
        sentFolderMail.add(FolderMail(
            id: 74636336,
            to: toController.text,
            date: DateTime.now().toString(),
            from_name: "Me",
            subject: subjectController.text));
        notifyListeners();
        print("------------abcd ${activeAccountid}");
        // Update Sent Items
        var sentResponse = await fetchFolderMail(activeAccountid, 'Sent');
        if (sentResponse != null) {
          List data = sentResponse.data['emails'];
          sentFolderMail = List.generate(
              data.length, (int index) => FolderMail.fromJson(data[index]));
        }
        notifyListeners();
      } else {
        locator<ToastService>().showToast("Couldn't send mail");
      }
    } catch (error) {
      locator<ToastService>().showToast("Something wen't wrong");
      logger.e('error fetching folder email', error);
      return false;
    }
    mailsending = false;
    notifyListeners();
  }

  Future addAccount(data) async {
    try {
      // Map<String, dynamic> data = {"google_auth": credentials.toString()};

      Response response = await EmailRepository().addMailAccount(data);
      print(
          "------------------------ addMail Resopose ${response} ${response.statusCode}");
      if (response.statusCode == 201) {
        await fetchEmailAccounts();
        // await LoadAccountMails(response);

        locator<ToastService>().showToast('New Email Account Added');
        return true;
      } else {
        locator<ToastService>()
            .showToast(response.data['message'] ?? "Unable to add account");
        return false;
      }
    } catch (error) {
      logger.e('error adding email accounts', error);
      locator<ToastService>().showToast("Error adding email");
      return false;
    }
  }

  Future addGoogleAccount(credentials) async {
    Map<String, dynamic> data = {"google_auth": credentials.toString()};

    try {
      Response response = await EmailRepository().addGmail(data);
      print(
          "------------------------ addMail Resopose ${response} ${response.statusCode}");
      if (response.statusCode == 200) {
        await fetchEmailAccounts();
        // await LoadAccountMails(response);

        locator<ToastService>().showToast('New Email Account Added');
        return true;
      } else {
        locator<ToastService>()
            .showToast(response.data['message'] ?? "Unable to add account");
        return false;
      }
    } catch (error) {
      logger.e('error adding email accounts', error);
      locator<ToastService>().showToast("Error adding email");
      return false;
    }
  }
}

/*---------------------------PROFILE UPDATE START---------------------------*/
// File? imageFile;
// XFile? xImage;
// bool imageSet = false;

// void snapPicture() async {
//   try {
//     final ImagePicker picker = ImagePicker();
//     var pickedFile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 90, maxHeight: 900, maxWidth: 900);
//     final imagePath = File(pickedFile!.path);
//     xImage = pickedFile;
//     imageFile = imagePath;
//     imageSet = true;
//     notifyListeners();
//   } catch (error) {
//     AppLogger().e("error uploading $error");
//   }
// }

// void removeUpload(index) {
//   imageFile = null;
//   notifyListeners();
// }

/*---------------------------PROFILE UPDATE ENDS---------------------------*/
