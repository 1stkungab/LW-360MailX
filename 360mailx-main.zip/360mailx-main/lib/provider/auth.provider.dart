import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/theme.config.dart';
import 'package:loveworld_mail/constant/authstate.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/model/account.model.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/account.repository.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:loveworld_mail/storage/app.storage.dart';
import 'package:loveworld_mail/utilities/logger.dart';

class AuthProvider extends ChangeNotifier {
  Account? _userdata;
  Account? get userdata => _userdata;

  String _token = "";
  String? get token => _token;

  bool _themeStatus = true;
  bool get themeStatus => _themeStatus;

  Future<bool> signin(Map<String, dynamic> payload, context) async {
    try {
      Response response = await AccountRepository().signin(payload);

      if (response.statusCode == 200) {
        var account = response.data['data'];
        var token = response.data['token'];
        _userdata = Account.fromJson(account);
        _token = token;
        AppStorage().updateToken(token);
        return true;
      } else {
        locator<ToastService>().showToast('Invalid Credentials');
        return false;
      }
    } catch (error) {
      print(error);
      locator<ToastService>().showToast('Something went wrong!');
      return false;
    }
  }

    Future<bool> signinWithKC(Map<String, dynamic> payload) async {
    try {
        var account = payload['data'];
        var token = payload['token'];
        _userdata = Account.fromJson(account);
        _token = token;
        AppStorage().updateToken(token);
        return true;
    } catch (error) {
      print(error);
      locator<ToastService>().showToast('Something went wrong!');
      return false;
    }
  }

  Future<bool> signup(Map<String, dynamic> payload, context) async {
    try {
      Response response = await AccountRepository().signup(payload);

      logger.e('signup response $response');

      if (response.statusCode == 200) {
        var account = response.data['data'];
        var token = response.data['token'];
        _userdata = Account.fromJson(account);
        _token = token;
        AppStorage().updateToken(token);
        return true;
      } else {
        locator<ToastService>().showToast(response.data['message']);
        return false;
      }
    } catch (error) {
      print(error.toString());
      locator<ToastService>().showToast('Something went wrong!');
      return false;
    }
  }

  void logout(BuildContext context) async {
    context.go(AppRoutes.authentication);
    await AppStorage().clearToken();
  }

  Future<bool> profile() async {
    try {
      Response response = await AccountRepository().fetchprofile();
      if (response.statusCode == 200) {
        Account model = Account.fromJson(response.data['data']);
        _userdata = model;
        return true;
      } else {
        locator<ToastService>().showToast(response.data['message']);
        return false;
      }
    } catch (error) {
      locator<ToastService>()
          .showToast('Something went wrong fetching profile!');
      return false;
    }
  }

  Future<bool> requestOTP() async {
    try {
      Response response =
          await AccountRepository().requestotp({'email': emailController.text});

      if (response.statusCode == 200) {
        return true;
      } else {
        locator<ToastService>().showToast(response.data['message']);
        return false;
      }
    } catch (error) {
      locator<ToastService>()
          .showToast('Something went wrong fetching profile!');
      return false;
    }
  }

  Future<bool> verifyEmailOTP(payload) async {
    try {
      Response response = await AccountRepository().verifyotp(payload);

      if (response.statusCode == 200) {
        return true;
      } else {
        locator<ToastService>().showToast("Invalid OTP");
        return false;
      }
    } catch (error) {
      locator<ToastService>()
          .showToast('Something went wrong fetching profile!');
      return false;
    }
  }

  Future<bool> forgetPassword(payload) async {
    try {
      Response response = await AccountRepository().forgetpassword(payload);

      if (response.statusCode == 200) {
        locator<ToastService>().showToast(response.data['message']);
        return true;
      } else {
        locator<ToastService>().showToast(response.data['message']);
        return false;
      }
    } catch (error) {
      locator<ToastService>().showToast('Invalid Email');
      return false;
    }
  }

    Future<bool> updateProfile(payload) async {

      print("Hello $payload");
    try {
      Response response = await AccountRepository().updateprofile(payload);


      logger.e("message $response");

      if (response.statusCode == 200) {
        profile();
        locator<ToastService>().showToast(response.data['message']);
        return true;
      } else {
        locator<ToastService>().showToast(response.data['message']);
        return false;
      }
    } catch (error) {
      locator<ToastService>().showToast('Invalid Email');
      return false;
    }
  }


  Future<AUTHENTICATIONSTATEENUM> validateAuthentication(context) async {
    _themeStatus = await AppStorage().readTheme();
    var authenticationtoken = await AppStorage().readToken();
    var onboarded = await AppStorage().readOnboarded();
    _token = authenticationtoken;

    notifyListeners();
    AppTheme().init(light: themeStatus);

    if (authenticationtoken == "null") {
      if (onboarded == "null") {
        return AUTHENTICATIONSTATEENUM.ONBOARDING;
      } else {
        return AUTHENTICATIONSTATEENUM.LOGIN;
      }
    }

    bool status = await profile();
    if (!status) {
      return AUTHENTICATIONSTATEENUM.LOGIN;
    }

    return AUTHENTICATIONSTATEENUM.DASHBOARD;
  }

  void gotoprofile() async {
    if (userdata != null) {
      firstnameController.text = userdata!.fname!;
      lastnameController.text = userdata!.lname!;
      emailController.text = userdata!.email!;
      phoneController.text = userdata!.phone!;
      startDateController.text = userdata!.dob!;
      genderController.text = userdata!.gender!;

      locator<GoRouter>().push(AppRoutes.updateprofile);
    }
  }
}
