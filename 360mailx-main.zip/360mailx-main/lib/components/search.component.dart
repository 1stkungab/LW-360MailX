  import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/routing/route.path.dart';

searchComponent(BuildContext context, List<FolderMail> mails, page) {
    return GestureDetector(
            onTap: () {
              // context.push(AppRoutes.searchpage);

              context.push(AppRoutes.searchpage, extra: {'mails': mails, 'page': page} );

            },
            child: AbsorbPointer(
              child: TextFormField(
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  prefixIcon: const Icon(
                    Icons.search_outlined,
                    color: Colors.grey,
                  ),
                  hintText: 'Search',
                  border: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.grey, width: 1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
            ),
          );
  }