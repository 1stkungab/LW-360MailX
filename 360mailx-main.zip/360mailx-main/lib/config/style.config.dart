import 'package:flutter/material.dart';

class AppTextStyles {
  static late ThemeData _theme;

  static void init(BuildContext context) {
    _theme = Theme.of(context);
  }

  static TextStyle small() {
    return const TextStyle(
      fontSize: 12,
    );
  }

  static TextStyle caption() {
    return const TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.normal,
    );
  }

  static TextStyle body() {
    return const TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.normal,
    );
  }

  static TextStyle header() {
    return const TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.w600,
    );
  }

  static TextStyle title({Color? color}) {
    return const TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
    );
  }

  static TextStyle large() {
    return TextStyle(
      fontSize: 24,
      fontWeight: FontWeight.bold,
      color: _theme.textTheme.bodyLarge!.color,
    );
  }

  static TextStyle extraLarge() {
    return TextStyle(
      fontSize: 32,
      fontWeight: FontWeight.bold,
      color: _theme.textTheme.bodyLarge!.color,
    );
  }
}
