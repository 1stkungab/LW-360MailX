import 'package:flutter/material.dart';

List<BoxShadow> appBoxShadow = [
  BoxShadow(
    color: Colors.grey.withOpacity(0.1),
    spreadRadius: 1,
    blurRadius: 2,
    offset: const Offset(0, 1),
  ),
];

List<BoxShadow> appBoxShadowSpread = [
  BoxShadow(
    color: Colors.grey.withOpacity(0.1),
    spreadRadius: 1,
    blurRadius: 2,
  ),
];
