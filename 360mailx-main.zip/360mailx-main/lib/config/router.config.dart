import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/pages/dashboard/global.webview.page.dart';
import 'package:loveworld_mail/pages/dashboard/html.emaildetails.page.dart';
import 'package:loveworld_mail/pages/dashboard/profile.page.dart';
import 'package:loveworld_mail/pages/dashboard/kingschat.webview.page.dart';
import 'package:loveworld_mail/pages/mainscafold.dart';
import 'package:loveworld_mail/pages/authentication/auth.page.dart';
import 'package:loveworld_mail/pages/authentication/changepassword.page.dart';
import 'package:loveworld_mail/pages/authentication/emailverification.page.dart';
import 'package:loveworld_mail/pages/authentication/otp.page.dart';
import 'package:loveworld_mail/pages/authentication/phone.page.dart';
import 'package:loveworld_mail/pages/authentication/signin.page.dart';
import 'package:loveworld_mail/pages/authentication/signup.page.dart';
import 'package:loveworld_mail/pages/dashboard/addaccount.page.dart';
import 'package:loveworld_mail/pages/dashboard/emaildetails.page.dart';
import 'package:loveworld_mail/pages/dashboard/inbox.page.dart';
import 'package:loveworld_mail/pages/dashboard/search.page.dart';
import 'package:loveworld_mail/pages/dashboard/sent.page.dart';
import 'package:loveworld_mail/pages/dashboard/settings.page.dart';
import 'package:loveworld_mail/pages/dashboard/starred.page.dart';
import 'package:loveworld_mail/pages/dashboard/trash.page.dart';
import 'package:loveworld_mail/pages/onboarding/onboarding.dart';
import 'package:loveworld_mail/pages/splash.page.dart';
import 'package:loveworld_mail/routing/route.path.dart';

// DOCUMENTATION
// https://www.flutfast.com/blogs/why-we-use-go-router

// TAB KEYS
final _rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');
final _inboxNavigatorKey = GlobalKey<NavigatorState>();
final _sentNavigatorKey = GlobalKey<NavigatorState>();
final _starredNavigatorKey = GlobalKey<NavigatorState>();
final _trashNavigatorKey = GlobalKey<NavigatorState>();

class AppRouter {
  static final GoRouter _router = GoRouter(
    navigatorKey: _rootNavigatorKey,
    routes: [
      StatefulShellRoute.indexedStack(
          builder: (context, state, navigationShell) {
            return MainDashboard(navigationShell: navigationShell);
          },
          branches: [
            // ROUTES FOE THE FIRST TAB #HOME
            StatefulShellBranch(
                navigatorKey: _inboxNavigatorKey,
                initialLocation: AppRoutes.inboxpage,
                routes: [
                  GoRoute(
                      path: AppRoutes.inboxpage,
                      builder: (context, state) {
                        return const InboxPage();
                      }),
                  GoRoute(
                      path: AppRoutes.searchpage,
                      builder: (context, state) {
                        final extraObject = state.extra as Map<String, dynamic>;
                        List<FolderMail> mails = extraObject['mails'] ?? [];
                        String page = extraObject['page'] ?? "inbox";
                        return  SearchPage(
                          mails: mails, page: page,
                        );
                      }),
                  GoRoute(
                      path: AppRoutes.addaccountpage,
                      builder: (context, state) {
                        return const AddAccountPage();
                      }),
                  GoRoute(
                      path: AppRoutes.settingpage,
                      builder: (context, state) {
                        return const SettingPage();
                      }),
                  GoRoute(
                      path: AppRoutes.updateprofile,
                      builder: (context, state) {
                        return const ProfilePage();
                      }),
                  GoRoute(
                      path: AppRoutes.emaildetailspage,
                      builder: (context, state) {
                        return const EmailDetailsPage();
                      }),
                  GoRoute(
                      path: AppRoutes.htmlemaildetailspage,
                      builder: (context, state) {
                        return const HtmlEmailDetailsPage();
                      }),
                ]),
            // ROUTES FOE THE SECOND TAB #HOME
            StatefulShellBranch(
                navigatorKey: _starredNavigatorKey,
                initialLocation: AppRoutes.starredpage,
                routes: [
                  GoRoute(
                      path: AppRoutes.starredpage,
                      builder: (context, state) {
                        return const StarredPage();
                      }),
                ]), // ROUTES FOE THE THIRD TAB #HOME
            StatefulShellBranch(
                navigatorKey: _sentNavigatorKey,
                initialLocation: AppRoutes.sentpage,
                routes: [
                  GoRoute(
                      path: AppRoutes.sentpage,
                      builder: (context, state) {
                        return const SentPage();
                      }),
                ]), // ROUTES FOE THE FOURTH TAB #HOME
            StatefulShellBranch(
                navigatorKey: _trashNavigatorKey,
                initialLocation: AppRoutes.trashpage,
                routes: [
                  GoRoute(
                      path: AppRoutes.trashpage,
                      builder: (context, state) {
                        return const TrashPage();
                      }),
                ]),
          ]),

      GoRoute(
          path: AppRoutes.splash,
          builder: (context, state) {
            return const SplashPage();
          }),
      GoRoute(
          path: AppRoutes.onboarding,
          builder: (context, state) {
            return const OnboardingPage();
          }),
      GoRoute(
          path: AppRoutes.authentication,
          builder: (context, state) {
            return const AuthenticationPage();
          }),
      GoRoute(
          path: AppRoutes.signinpage,
          builder: (context, state) {
            return const SigninPage();
          }),
      GoRoute(
          path: AppRoutes.kingschatlogin,
          builder: (context, state) {
            final extraObject = state.extra as Map<String, String>;
            String randomDeviceId = extraObject['randomDeviceId'] ?? "";
            return KingsChatLogin(randomDeviceId: randomDeviceId);
          }),

      GoRoute(
          path: AppRoutes.globalwebview,
          builder: (context, state) {
            final extraObject = state.extra as Map<String, String>;
            String title = extraObject['title'] ?? "";
            String link = extraObject['link'] ?? "";
            return GlobalWebView(
              title: title,
              link: link,
            );
          }),

      GoRoute(
          path: AppRoutes.signuppage,
          builder: (context, state) {
            return const SignupPage();
          }),
      GoRoute(
          path: AppRoutes.phonepage,
          builder: (context, state) {
            return const PhonePage();
          }),
      GoRoute(
          path: AppRoutes.verifyemail,
          builder: (context, state) {
            return const EmailVerification();
          }),
      GoRoute(
          path: AppRoutes.changepassword,
          builder: (context, state) {
            return const Changepassword();
          }),
      GoRoute(
          path: AppRoutes.otppage,
          builder: (context, state) {
            return const OTPPage();
          }),
      GoRoute(
          path: AppRoutes.firstaddaccountpage,
          builder: (context, state) {
            return const AddAccountPage();
          }),
      // GoRoute(
      //     path: AppRoutes.resetpassword,
      //     builder: (context, state) {
      //       return const ResetPasswordPage();
      //     }),
      // GoRoute(
      //     path: AppRoutes.passwordresetsuccess,
      //     builder: (context, state) {
      //       return const PasswordResetSuccessPage();
      //     }),
    ],
    redirect: (context, state) async {
      return null;
    },
  );

  GoRouter get router => _router;
}
