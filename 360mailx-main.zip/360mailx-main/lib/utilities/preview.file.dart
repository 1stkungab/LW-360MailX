
  import 'dart:io';

import 'package:flutter/material.dart';

previewFile(File? file, Function()? action) {

    if (file == null) return const Text("");

    String filePath = file.path;
    String fileName = filePath.split('/').last;

    // Determine icon based on file extension
    IconData icon;
    if (filePath.endsWith('.jpg') || filePath.endsWith('.jpeg') || filePath.endsWith('.png')) {
      icon = Icons.image;
    } else if (filePath.endsWith('.pdf')) {
      icon = Icons.picture_as_pdf;
    } else if (filePath.endsWith('.doc') || filePath.endsWith('.docx')) {
      icon = Icons.description;
    } else if (filePath.endsWith('.mp4') || filePath.endsWith('.avi')) {
      icon = Icons.videocam;
    } else {
      icon = Icons.insert_drive_file; // Default icon for other file types
    }

    return ListTile(
      leading: Icon(icon, size: 40, color: Colors.blueAccent),
      title: Text(fileName),
      subtitle: GestureDetector(
        onTap: action,
        child: const Text("Tap to clear")),
    );
  }