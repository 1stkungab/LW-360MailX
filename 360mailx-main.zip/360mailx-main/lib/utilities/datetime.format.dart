import 'package:intl/intl.dart';

String formatDateTime(String? dateStr) {
  if (dateStr == null || dateStr.isEmpty) {
    return "";
  }

  try {
    final DateTime date = DateTime.parse(dateStr);
    return DateFormat('d MMM').format(date); 
  } catch (e) {
    return ""; 
  }
}
