  import 'package:flutter/material.dart';

RichText loveworldText(BuildContext context, {double? size  = 18}) {
    return RichText(
        text: TextSpan(
          text: '360', // First part
          style: TextStyle(
            color: Theme.of(context).textTheme.bodyLarge!.color,
            fontSize: size,
            fontWeight: FontWeight.w600,
          ),
          children: [
             TextSpan(
              text: 'Mail',
              style: TextStyle(
                color: Theme.of(context).primaryColor,
              ),
            ),
            TextSpan(
              text: 'X',
              style: TextStyle(
                color: Theme.of(context).textTheme.bodyLarge!.color,
              ),
            ),
          ],
        ),);
  }