
String truncateBody(String body, {int maxLength = 150}) {
  if (body.length > maxLength) {
    return "${body.substring(0, maxLength)}...";
  }
  return body;
}
