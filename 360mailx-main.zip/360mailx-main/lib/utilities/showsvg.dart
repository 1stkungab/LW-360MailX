import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter/widgets.dart';

Widget loadSvg({
  required String path,
  bool isAsset = true,
  double size = 200,
  Color? color
}) {
  return isAsset
      ? SvgPicture.asset(
          path,
          width: size,
          height: size,
           // ignore: deprecated_member_use
           color: color,
        )
      : SvgPicture.network(
          path,
          width: size,
          height: size,
        );
}
