import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/routing/navigator_1.0.dart';


class ToastUtil  {
  void showToast(String message) {
    AppNavigatorKeys.instance.scaffoldKey.currentState?.showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        elevation: 0.8,
        backgroundColor: AppColors.primary, 
        duration: const Duration(seconds: 3),
      ),
    );
  }
}
