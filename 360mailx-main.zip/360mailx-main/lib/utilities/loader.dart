import 'package:flutter/material.dart';

fetchLoader(size) {

    return Padding(
      padding: EdgeInsets.all(5.0),
      child: Center(
          child: SizedBox(
              width: size,
              height: size,
              child: CircularProgressIndicator(
                strokeWidth: 2,
              ))),
    );
}
