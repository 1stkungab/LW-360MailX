     truncateDescription(String description, int wordLimit) {
      final words = description.split(' ');
      if (words.length <= wordLimit) {
        return description;
      } else {
        return '${words.take(wordLimit).join(' ')}...'; // Add ellipsis if truncated
      }
    }


    truncateTitle(String description, int wordLimit) {
      final words = description.split('');
      if (words.length <= wordLimit) {
        return description;
      } else {
        return '${words.take(wordLimit).join('')}...'; // Add ellipsis if truncated
      }
    }