import 'package:intl/intl.dart';

String formatTime(DateTime date) {
  final DateFormat formatter = DateFormat('h:mma');
  return formatter.format(date);
}
