// extension StringExtension on String {
//     String toCamelCase() {
//       return "${this[0].toUpperCase()}${substring(1).toLowerCase()}";
//     }
// }

extension StringExtension on String {
  String toCamelCase() {
    if (isEmpty) return this;

    final words = split(' ');

    final camelCaseWords = words.map((word) {
      if (word.isEmpty) return word;
      final lowercasedWord = word.toLowerCase();
      final capitalizedWord = lowercasedWord[0].toUpperCase() + lowercasedWord.substring(1);
      return capitalizedWord;
    }).toList();

    return camelCaseWords.join(' ');
  }
}
