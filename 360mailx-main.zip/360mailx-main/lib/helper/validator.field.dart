class Validator {
  static String? validateEmail(String email) {
    final RegExp emailRegExp = RegExp(
      r'^[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z]+',
    );
    if (email.isEmpty) {
      return 'Email cannot be empty';
    } else if (!emailRegExp.hasMatch(email)) {
      return 'Enter a valid email';
    }
    return null;
  }

  static String? validatePassword(String password) {
    if (password.isEmpty) {
      return 'Password cannot be empty';
    } else if (password.length < 5) {
      return 'Password must be at least 5 characters';
    }
    return null;
  }

  static String? validatePasswordMatch(String password1, String password2) {
    if (password1 != password2) {
      return 'Password does not match';
    } 
    return null;
  }

  static String? validateName(String name) {
    if (name.isEmpty) {
      return 'Name cannot be empty';
    }
    return null;
  }

    static String? validatePhone(String number) {
    if (number.isEmpty) {
      return 'Number cannot be empty';
    }
    return null;
  }
}
