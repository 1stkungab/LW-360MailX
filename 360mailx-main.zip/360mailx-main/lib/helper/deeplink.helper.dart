import 'dart:async';
import 'package:app_links/app_links.dart';
import 'package:loveworld_mail/utilities/logger.dart';


// DEPRECIATED: NOW HANDLED BY GO_ROUTER
class DeepLinkHandler {
  late AppLinks _appLinks;
  StreamSubscription<Uri>? _linkSubscription;

  void initDeepLinks() {
    _appLinks = AppLinks();

    _linkSubscription = _appLinks.uriLinkStream.listen((uri) {
      _openAppLink(uri);
    });
  }

  void _openAppLink(Uri uri) async {
      AppLogger().e('-------------onAppLink------------: $uri');
      await Future.delayed(const Duration(milliseconds: 50));
      // locator<GoRouter>().push(AppRoutes.community);
  }

  void dispose() {
    _linkSubscription?.cancel();
  }
}
