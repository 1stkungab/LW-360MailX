import 'package:shared_preferences/shared_preferences.dart';

class AppStorage {
  Future<String> readToken() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String loggedUser = prefs.getString('token') ?? "null";
    return loggedUser;
  }

  Future<dynamic> updateToken(data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var value = await prefs.setString('token', data);
    return value;
  }

    Future<String> readOnboarded() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String loggedUser = prefs.getString('onboarded') ?? "null";
    return loggedUser;
  }

  Future<dynamic> updateOnboarded(data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var value = await prefs.setString('onboarded', data);
    return value;
  }

  Future<bool> readTheme() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    bool loggedUser = prefs.getBool('theme') ?? true;
    return loggedUser;
  }

    Future<List<String>> readBookmark() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> data = prefs.getStringList('bookmark') ?? [];
    return data;
  }

    Future<bool> updateBookmark(List<String> data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    bool value = await prefs.setStringList('bookmark', data);
    return value;
  }

  Future<bool> updateTheme(data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    bool value = await prefs.setBool('theme', data);
    return value;
  }

    Future<bool> updateStreak(data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    bool value = await prefs.setString('streak', data);
    return value;
  }

    Future<String> readStreak() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String loggedUser = prefs.getString('streak') ?? "null";
    return loggedUser;
  }

  Future<bool> readNotification() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    bool loggedUser = prefs.getBool('notification') ?? true;
    return loggedUser;
  }

  Future<bool> updateNotification(data) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    bool value = await prefs.setBool('notification', data);
    return value;
  }

  Future<dynamic> clearToken() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var value = await prefs.remove('token');
    return value;
  }

  Future<String> read({String dataKey = ""}) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    String loggedUser = prefs.getString('token') ?? "null";
    return loggedUser;
  }

  Future<dynamic> set({String dataKey = "", required String data}) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    var value = await prefs.setString('token', data);
    return value;
  }
}