import 'package:flutter_dotenv/flutter_dotenv.dart';

class ApiRoutes {
  static String base = dotenv.env['URL'] ?? "";

  // AUTHENTICATION
  static String signin = "$base/login";
  static String signup = "$base/register";
  static String readprofile = "$base/profile";
  static String requestotp = "$base/send-email-verification-otp";
  static String verifyotp = "$base/verify-email-otp";
  static String forgetpassword = "$base/password/forgot";
  static String resetpassword = "$base/register";
  static String fetchprofile = "$base/login";
  static String updateprofile = "$base/update/profile";
  static String kingschatlogin = "$base/login";
  static String emailaccounts = "$base/mail/accounts";
  static String folders = "$base/mail/folders";
  static String foldermail = "$base/mail/folder-mails";
  static String folderstarredmail = "$base/mail/starred";
  static String individualMail = "$base/mail/individual-message";
  static String addEmailAccount = "$base/mail/add-mail";
  static String sendMail = "$base/mail/send";
  static String deleteAccount = "$base/mail/delete-account";
  static String addGmail = "$base/mail/google/store-auth-response";
  static String starMail = "$base/mail/star";
  static String trashMail = "$base/mail/trash-email";
  static String permanentDelete = "$base/mail/delete-email";
  static String restore = "$base/mail/restore";

}
