class AppAssets {
  static String splashLogo = "assets/icon/appicon.png";

    static String altlogo = "assets/logo/altlogo.jpeg";
    static String altlogotrans = "assets/logo/altlogo.png";


  static String onboard1 = "assets/svg/unboard1.svg";
  static String onboard2 = "assets/svg/unboard2.svg";
  static String onboard3 = "assets/svg/unboard3.svg";

  static String onboard4 = "assets/svg/unboard4.svg";
  static String onboard5 = "assets/svg/unboard5.svg";
  static String onboard6 = "assets/svg/unboard6.svg";

  static String onboard7 = "assets/svg/unboard7.svg";
  static String onboard8 = "assets/svg/unboard8.svg";
  static String onboard9 = "assets/svg/unboard9.svg";

  static String inbox = "assets/svg/inbox.svg";
  static String starred = "assets/svg/favourite.svg";
  static String sent = "assets/svg/sent.svg";
  static String trash = "assets/svg/trash.svg";

  static String auth = "assets/images/auth.png";

  static String miniuser1 = "assets/images/miniuser1.png";
  static String miniuser2 = "assets/images/miniuser2.png";
  static String miniuser3 = "assets/images/miniuser3.png";
  static String miniuser4 = "assets/images/miniuser4.png";
  static String miniuser5 = "assets/images/miniuser5.png";
  static String miniuser6 = "assets/images/miniuser6.png";
  static String miniuser7 = "assets/images/miniuser7.png";

  static String smilingman = "assets/images/guy.png";
  static String smilinglady = "assets/images/lady.png";

  static String blue = "assets/images/blue.jpg";

  static String google = "assets/icons/google.png";
  static String facebook = "assets/icons/facebook.png";
  static String apple = "assets/icons/apple.png";
  static String yahoo = "assets/logo/yahoo.png";
  static String loveworld = "assets/logo/logo.png";
  static String webmail = "assets/logo/webmail.png";
  static String kingschat = "assets/icons/kingschat.webp";

// LOTTIE
  static String successgreen = "assets/lottie/success_green.json";
  static String emptymail = "assets/lottie/mail.gif";

  static String banner1 = "assets/banners/banner1.jpg";
  static String banner2 = "assets/banners/banner2.jpg";
  static String banner3 = "assets/banners/banner3.jpg";
  static String banner4 = "assets/banners/banner4.jpg";
}
