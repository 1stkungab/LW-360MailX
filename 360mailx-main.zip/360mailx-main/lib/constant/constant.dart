String coverURL = "https://picsum.photos/200";
String bannerUrl = "https://picsum.photos/700/300";

String rendering =
    """<h5 style="color: gray; text-align: center;">Rendering Mail...</h5>""";

String renderingv2 = """
    <h1>Hello </h1>
    <h2 style='color:red'>World</h2>
    <p>This is sample paragraph</p>
    <p> H<sup>2</sup>O </p>
    <p> A<sub>2</sub> </p>
    <i>italic</i> <b>bold</b> <u>underline</u> <s>strike </s>
    <ul>
      <li>Item 1</li>
      <li>Item 2</li>
      <li>Item 3</li>
    </ul>
    <br><br>
    <img src="https://vrsofttech.com/flutter-tutorials/images/vr.png" width="100">
  """;

String aboutus = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About 360MailX</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
            line-height: 1.6;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }
        h1 {
            color: #0056b3;
            font-size: 28px;
        }
        p {
            font-size: 16px;
            padding: 10px 20px;
        }
        .highlight {
            color: #0056b3;
            font-weight: bold;
        }
        .features {
            text-align: left;
            padding: 0 20px;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        ul li {
            background: url('https://cdn-icons-png.flaticon.com/16/845/845646.png') no-repeat left center;
            background-size: 16px;
            padding-left: 25px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>About <span class="highlight">360MailX</span></h1>
        <p>
            <strong>360MailX</strong> is a modern, secure, and intuitive email management tool designed to simplify your communication.
        </p>
        <div class="features">
            <p>Our product provides a seamless experience across devices, combining robust features such as:</p>
            <ul>
                <li>Advanced Search</li>
                <li>Smart Email Management</li>
                <li>Productivity Tools</li>
                <li>Enhanced Security</li>
                <li>Customization Options</li>
                <li>Third-Party Integrations</li>
            </ul>
        </div>
        <p>
            Built with <strong>user privacy and security</strong> in mind, 360MailX ensures your data is safe while empowering you to manage your inbox effortlessly.
        </p>
        <p>
            Whether you're an individual or a professional, <strong>360MailX adapts</strong> to your needs, helping you stay <span class="highlight">organized, effective, and productive</span>.
        </p>
    </div>
</body>
</html>

""";
