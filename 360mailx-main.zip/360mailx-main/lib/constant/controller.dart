import 'package:flutter/material.dart';

final firstnameController = TextEditingController();
final lastnameController = TextEditingController();
final bioController = TextEditingController();
final passwordController = TextEditingController();
final confirmPasswordController = TextEditingController();
final emailController = TextEditingController();
final phoneController = TextEditingController();
final captionController = TextEditingController();
final youtubeController = TextEditingController();
final mixlrController = TextEditingController();

final startDateController = TextEditingController();
final closeDateController = TextEditingController();

final genderController = TextEditingController();


final startTimeController = TextEditingController();
final closeTimeController = TextEditingController();

final hostController = TextEditingController();
final facilitatorsController = TextEditingController();


final titleController = TextEditingController();
final descriptionController = TextEditingController();
final authorController = TextEditingController();
final pagesController = TextEditingController();
final chaptersController = TextEditingController();


final noteController = TextEditingController();


final toController = TextEditingController();
final ccController = TextEditingController();
final bccController = TextEditingController();
final fromController = TextEditingController();
final subjectController = TextEditingController();
final bodyController = TextEditingController();

final List<TextEditingController> controllers =
        List.generate(6, (index) => TextEditingController());






  final formKey = GlobalKey<FormState>();

  // final TextEditingController mailController = TextEditingController(text: "kungab360x@outlook.com");
  // final TextEditingController passController =
  //     TextEditingController(text: "my_LWmailclient");
  // // final TextEditingController mailServiceIdController =
  // //     TextEditingController(text: "1");
  // final TextEditingController incomingServerUrlController =
  //     TextEditingController(text: "outlook.office365.com");
  // final TextEditingController incomingServerPortController =
  //     TextEditingController(text: "993");
  // final TextEditingController incomingSecurityTypeController =
  //     TextEditingController(text: "SSL");
  // final TextEditingController outgoingServerUrlController =
  //     TextEditingController(text: "smtp-mail.outlook.com");
  // final TextEditingController outgoingServerPortController =
  //     TextEditingController(text: "587");
  // final TextEditingController outgoingSecurityTypeController =
  //     TextEditingController(text: "SSL");
  // final TextEditingController accountNameController =
  //     TextEditingController(text: "Kungab oUTLOOK");


  final TextEditingController mailController = TextEditingController();
  final TextEditingController passController =
      TextEditingController();
  final TextEditingController mailServiceIdController = TextEditingController();
  final TextEditingController incomingServerUrlController =
      TextEditingController();
  final TextEditingController incomingServerPortController =
      TextEditingController();
  final TextEditingController incomingSecurityTypeController =
      TextEditingController();
  final TextEditingController outgoingServerUrlController =
      TextEditingController();
  final TextEditingController outgoingServerPortController =
      TextEditingController();
  final TextEditingController outgoingSecurityTypeController =
      TextEditingController();
  final TextEditingController accountNameController =
      TextEditingController();
