const int animationDelay = 400;
