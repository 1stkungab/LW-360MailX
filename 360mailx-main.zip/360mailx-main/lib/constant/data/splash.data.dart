
import 'package:loveworld_mail/constant/asset.path.dart';

List onboaedingdata = [
  {
    'title': 'Intuitive Interface',
    'description': 'Our clean and intuitive interface ensures you can navigate your inbox effortlessly, saving you time and reducing clutter.',
    'image': AppAssets.onboard1,
  },
  {
    'title': 'Advanced Security',
    'description': 'We prioritize your privacy with robust encryption and advanced security measures, keeping your emails safe from prying eyes.',
    'image': AppAssets.onboard2,
  },
  {
    'title': 'Smart Organization',
    'description': 'Say goodbye to email overload. Our smart organization features categorize your emails automatically, so you can focus on what matters most.',
    'image': AppAssets.onboard3,
  }
];
