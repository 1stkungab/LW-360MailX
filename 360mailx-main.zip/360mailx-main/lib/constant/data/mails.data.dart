List<Map<String, dynamic>> dataz = [
  {
    "id": 1,
    "sender": "Quora Digest",
    "image": "",
    "title": "Are solar panels worth it?",
    "body":
        "Solar panels offer a clean energy solution, but initial costs can be high.",
    "priority": "high",
    "date": DateTime.now()
        .subtract(const Duration(days: 1))
        .toString(), // yesterday
  },
  {
    "id": 2,
    "sender": "Tech Today",
    "image": "https://example.com/image1.jpg",
    "title": "New AI models surpass human performance",
    "body":
        "AI models are advancing at a rapid pace, now even surpassing human capabilities in certain tasks.",
    "priority": "medium",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 3,
    "sender": "Health News",
    "image": "",
    "title": "Top 5 benefits of a plant-based diet",
    "body":
        "Plant-based diets can improve heart health and reduce risk of chronic diseases.",
    "priority": "low",
    "date": DateTime.now().add(const Duration(days: 1)).toString(), // tomorrow
  },
  {
    "id": 4,
    "sender": "Travel World",
    "image": "https://example.com/image2.jpg",
    "title": "Best destinations for 2024",
    "body":
        "Explore the most recommended travel spots around the world this year.",
    "priority": "high",
    "date": DateTime.now().add(const Duration(days: 7)).toString(), // next week
  },
  {
    "id": 5,
    "sender": "Finance Daily",
    "image": "",
    "title": "Understanding stock market trends",
    "body": "Learn how stock market fluctuations impact your investments.",
    "priority": "medium",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 6,
    "sender": "Eco Magazine",
    "image": "https://example.com/image3.jpg",
    "title": "Climate change and its effects",
    "body": "A deep dive into the impact of climate change on our planet.",
    "priority": "low",
    "date": DateTime.now()
        .subtract(const Duration(days: 1))
        .toString(), // yesterday
  },
  {
    "id": 7,
    "sender": "Fitness Insider",
    "image": "",
    "title": "10-minute workout routines",
    "body": "Short yet effective workout routines to fit in a busy schedule.",
    "priority": "high",
    "date": DateTime.now().add(const Duration(days: 1)).toString(), // tomorrow
  },
  {
    "id": 8,
    "sender": "Gadget Hub",
    "image": "https://example.com/image4.jpg",
    "title": "Top smartphones of 2024",
    "body": "A review of the latest and greatest smartphones.",
    "priority": "medium",
    "date": DateTime.now().add(const Duration(days: 7)).toString(), // next week
  },
  {
    "id": 9,
    "sender": "Food Lovers",
    "image": "",
    "title": "How to make sourdough bread at home",
    "body": "A beginner's guide to baking sourdough bread.",
    "priority": "low",
    "date": DateTime.now()
        .subtract(const Duration(days: 1))
        .toString(), // yesterday
  },
  {
    "id": 10,
    "sender": "Daily Tips",
    "image": "https://example.com/image5.jpg",
    "title": "Ways to save energy at home",
    "body": "Learn practical ways to reduce energy usage and save on bills.",
    "priority": "medium",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 11,
    "sender": "Quora Digest",
    "image": "",
    "title": "Are electric cars really eco-friendly?",
    "body":
        "Exploring the environmental benefits and concerns with electric cars.",
    "priority": "high",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 12,
    "sender": "Tech Crunch",
    "image": "https://example.com/image6.jpg",
    "title": "New breakthroughs in quantum computing",
    "body": "Quantum computing is closer than ever to revolutionizing tech.",
    "priority": "medium",
    "date": DateTime.now().add(const Duration(days: 1)).toString(), // tomorrow
  },
  {
    "id": 13,
    "sender": "Movie Buzz",
    "image": "",
    "title": "Top movies to watch in 2024",
    "body": "A curated list of must-watch movies this year.",
    "priority": "low",
    "date": DateTime.now().add(const Duration(days: 7)).toString(), // next week
  },
  {
    "id": 14,
    "sender": "Fashion Weekly",
    "image": "https://example.com/image7.jpg",
    "title": "Fall fashion trends you should know",
    "body": "Discover the latest in fall fashion and style.",
    "priority": "high",
    "date": DateTime.now()
        .subtract(const Duration(days: 1))
        .toString(), // yesterday
  },
  {
    "id": 14,
    "sender": "Auto News",
    "image": "",
    "title": "Electric vs. hybrid: Which is better?",
    "body": "Weighing the pros and cons of electric and hybrid vehicles.",
    "priority": "medium",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 15,
    "sender": "Space Insight",
    "image": "https://example.com/image8.jpg",
    "title": "NASA's latest mission to Mars",
    "body": "All you need to know about NASA’s new Mars exploration.",
    "priority": "low",
    "date": DateTime.now().add(const Duration(days: 1)).toString(), // tomorrow
  },
  {
    "id": 16,
    "sender": "Garden Guide",
    "image": "",
    "title": "5 tips for growing your own vegetables",
    "body": "Start your own vegetable garden with these beginner tips.",
    "priority": "medium",
    "date": DateTime.now().add(const Duration(days: 7)).toString(), // next week
  },
  {
    "id": 17,
    "sender": "Financial Times",
    "image": "",
    "title": "How inflation impacts your savings",
    "body": "Understanding the effects of inflation on personal finances.",
    "priority": "high",
    "date": DateTime.now()
        .subtract(const Duration(days: 1))
        .toString(), // yesterday
  },
  {
    "id": 19,
    "sender": "Travel Diaries",
    "image": "https://example.com/image9.jpg",
    "title": "Exploring the wonders of Japan",
    "body": "A traveler's guide to Japan's must-see destinations.",
    "priority": "low",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 20,
    "sender": "Wellness Today",
    "image": "",
    "title": "Meditation techniques for beginners",
    "body": "Discover how to start a daily meditation routine.",
    "priority": "medium",
    "date": DateTime.now().add(const Duration(days: 1)).toString(), // tomorrow
  },
  {
    "id": 21,
    "sender": "Quora Digest",
    "image": "https://example.com/image10.jpg",
    "title": "The future of renewable energy",
    "body": "An outlook on the trends in renewable energy.",
    "priority": "high",
    "date": DateTime.now().add(const Duration(days: 7)).toString(), // next week
  },
  {
    "id": 22,
    "sender": "Tech News",
    "image": "",
    "title": "Top gadgets for a smart home",
    "body": "Upgrade your home with the latest smart gadgets.",
    "priority": "medium",
    "date": DateTime.now()
        .subtract(const Duration(days: 1))
        .toString(), // yesterday
  },
  {
    "id": 23,
    "sender": "Eco News",
    "image": "https://example.com/image11.jpg",
    "title": "Reducing plastic waste",
    "body": "Practical steps to reduce plastic in daily life.",
    "priority": "low",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 24,
    "sender": "Fitness Trends",
    "image": "",
    "title": "At-home workouts vs gym workouts",
    "body": "Pros and cons of working out at home or at the gym.",
    "priority": "high",
    "date": DateTime.now().add(const Duration(days: 1)).toString(), // tomorrow
  },
  {
    "id": 25,
    "sender": "Health Update",
    "image": "https://example.com/image12.jpg",
    "title": "How to improve mental health",
    "body": "Tips for enhancing mental well-being.",
    "priority": "medium",
    "date": DateTime.now().add(const Duration(days: 7)).toString(), // next week
  },
  {
    "id": 26,
    "sender": "Science Daily",
    "image": "",
    "title": "What is CRISPR and its future potential?",
    "body": "Exploring the genetic editing tool CRISPR.",
    "priority": "low",
    "date": DateTime.now().toString(), // today
  },
  {
    "id": 27,
    "sender": "Quora Digest",
    "image": "",
    "title": "Is nuclear energy safe?",
    "body": "Evaluating the pros and cons of nuclear power.",
    "priority": "high",
    "date": DateTime.now()
        .subtract(const Duration(days: 1))
        .toString(), // yesterday
  },
  {
    "id": 28,
    "sender": "Sports Weekly",
    "image": "https://example.com/image13.jpg",
    "title": "Top players to watch this season",
    "body": "Get to know the most promising players in sports.",
    "priority": "medium",
    "date": DateTime.now().add(const Duration(days: 1)).toString(), // tomorrow
  },
  {
    "id": 29,
    "sender": "Book Club",
    "image": "",
    "title": "Must-read books for the year",
    "body": "A list of books you shouldn’t miss this year.",
    "priority": "low",
    "date": DateTime.now().add(const Duration(days: 7)).toString(), // next week
  }
];
