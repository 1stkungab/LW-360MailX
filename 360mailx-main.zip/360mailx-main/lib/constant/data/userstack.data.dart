import 'package:loveworld_mail/constant/asset.path.dart';

List userstackdata = [
  AppAssets.miniuser1,
  AppAssets.miniuser2,
  AppAssets.miniuser3,
  AppAssets.miniuser4,
];

