import 'package:dio/dio.dart';
import 'package:loveworld_mail/constant/route.api.dart';
import 'package:loveworld_mail/services/api.service.dart';

class AccountRepository {
  final BaseApi _baseApi = BaseApi();

  Future<Response> signin(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.signin, formData);
  }

  Future<Response> signup(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.signup, formData);
  }

  Future<Response> requestotp(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.requestotp, formData);
  }

  Future<Response> verifyotp(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.verifyotp, formData);
  }

  Future<Response> forgetpassword(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.forgetpassword, formData);
  }

  Future<Response> resetpassword(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.signup, formData);
  }

  Future<Response> fetchprofile() async {
    return await _baseApi.get(ApiRoutes.readprofile);
  }

  Future<Response> updateprofile(Map<String, dynamic> formData) async {
    return await _baseApi.path(ApiRoutes.updateprofile, formData);
  }

    Future<Response> kingsChat(url, body) async {
    return await _baseApi.get(url, body: body);
  }
}
