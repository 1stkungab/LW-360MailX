import 'package:dio/dio.dart';
import 'package:loveworld_mail/storage/app.storage.dart';
import 'package:loveworld_mail/utilities/logger.dart';

class BaseApi {
  final Dio dio;

  BaseApi() : dio = Dio() {
    dio.options.validateStatus = (status) {
      return status == 409 || (status != null && status >= 200 && status < 420);
    };

    // Add interceptors
    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          logger.d("Request [${options.method}] => PATH: ${options.path}");
          logger.d("Headers: ${options.headers}");
          logger.d("Data: ${options.data}");

          // Add Authorization header dynamically
          var authenticationToken = await AppStorage().readToken();
          if (authenticationToken != "null") {
            options.headers['Authorization'] = 'Bearer $authenticationToken';
            dio.options.headers['X-User'] = authenticationToken;
          } else {
            options.headers.remove('Authorization');
          }

          // Proceed with the request
          handler.next(options);
        },

        // onResponse: (response, handler) {
        //   logger.d("Response [${response.statusCode}] => PATH: ${response.requestOptions.path}");
        //   logger.d("Response Data: ${response.data}");
        //   handler.next(response);
        // },

        // onError: (DioError e, handler) {
        //   logger.e("Error [${e.response?.statusCode}] => PATH: ${e.requestOptions.path}");
        //   logger.e("Error Message: ${e.message}");
        //   logger.e("Error Data: ${e.response?.data}");

        //   // You can modify the error or retry the request here if necessary
        //   handler.next(e);
        // },
      ),
    );
  }

  Future<void> _setHeaders() async {
    var authenticationToken = await AppStorage().readToken();
    if (authenticationToken != "null") {
      dio.options.headers['Authorization'] = 'Bearer $authenticationToken';
      dio.options.headers['X-User'] = authenticationToken;
    } else {
      dio.options.headers.remove('Authorization');
    }
  }

  Future<Response> post(String url, Map<String, dynamic> data) async {
    await _setHeaders();
    try {
      Response response = await dio.post(url, data: data);
      return response;
    } catch (e) {
      if (e is DioError) {
        return Response(
          statusCode: e.response!.statusCode,
          statusMessage: e.message,
          requestOptions: RequestOptions(path: url),
        );
      } else {
        return Response(
          statusCode: 500,
          statusMessage: 'An error occurred',
          requestOptions: RequestOptions(path: url),
        );
      }
    }
  }

  Future<Response> get(String url,
      {Map<String, dynamic>? queryParameters,
      Map<String, dynamic>? body}) async {
    await _setHeaders();
    try {
      Response response = await dio.get(url, data: body);
      return response;
    } catch (e) {
      return Response(
        statusCode: 500,
        statusMessage: 'An error occurred',
        requestOptions: RequestOptions(path: url),
      );
    }
  }

  Future<Response> put(String url, Map<String, dynamic> data) async {
    await _setHeaders();
    try {
      Response response = await dio.put(url, data: data);
      return response;
    } catch (e) {
      return Response(
        statusCode: 500,
        statusMessage: 'An error occurred',
        requestOptions: RequestOptions(path: url),
      );
    }
  }

    Future<Response> path(String url, Map<String, dynamic> data) async {
    await _setHeaders();
    try {
      Response response = await dio.patch(url, data: data);
      return response;
    } catch (e) {
      return Response(
        statusCode: 500,
        statusMessage: 'An error occurred',
        requestOptions: RequestOptions(path: url),
      );
    }
  }

  Future<Response> delete(String url, {Map<String, dynamic>? data}) async {
    await _setHeaders();
    try {
      Response response = await dio.delete(url, data: data);
      return response;
    } catch (e) {
      return Response(
        statusCode: 500,
        statusMessage: 'An error occurred',
        requestOptions: RequestOptions(path: url),
      );
    }
  }

  Future<Response> postFormData(String url, FormData formData) async {
    await _setHeaders();
    try {
      Response response = await dio.post(url, data: formData);

      logger.e(response.toString());
      return response;
    } catch (e) {
      return Response(
        statusCode: 500,
        statusMessage: 'An error occurred',
        requestOptions: RequestOptions(path: url),
      );
    }
  }

  Future<Response> putFormData(String url, FormData formData) async {
    await _setHeaders();
    try {
      Response response = await dio.put(url, data: formData);
      return response;
    } catch (e) {
      return Response(
        statusCode: 500,
        statusMessage: 'An error occurred',
        requestOptions: RequestOptions(path: url),
      );
    }
  }
}
