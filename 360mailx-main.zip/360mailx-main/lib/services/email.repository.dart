import 'package:dio/dio.dart';
import 'package:loveworld_mail/constant/route.api.dart';
import 'package:loveworld_mail/services/api.service.dart';

class EmailRepository {
  final BaseApi _baseApi = BaseApi();

  Future<Response> accounts() async {
    return await _baseApi.get(ApiRoutes.emailaccounts);
  }

  Future<Response> folders(body) async {
    return await _baseApi.get(ApiRoutes.folders, body: body);
  }

  Future<Response> folderMails(body) async {
    return await _baseApi.get(ApiRoutes.foldermail, body: body);
  }

  Future<Response> folderStarredMails(body) async {
    return await _baseApi.get(ApiRoutes.folderstarredmail, body: body);
  }

  Future<Response> readMail(body) async {
    return await _baseApi.get(ApiRoutes.individualMail, body: body);
  }

  Future<Response> addMailAccount(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.addEmailAccount, formData);
  }

  Future<Response> sendMail(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.sendMail, formData);
  }

  Future<Response> deleteMailAccount(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.deleteAccount, formData);
  }

  Future<Response> addGmail(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.addGmail, formData);
  }

  Future<Response> starredMail(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.starMail, formData);
  }

  Future<Response> trashMail(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.trashMail, formData);
  }

  Future<Response> permanentDelete(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.permanentDelete, formData);
  }

  Future<Response> restore(Map<String, dynamic> formData) async {
    return await _baseApi.post(ApiRoutes.restore, formData);
  }
}
