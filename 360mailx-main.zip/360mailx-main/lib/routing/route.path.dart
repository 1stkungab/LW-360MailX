class AppRoutes {
  static const splash = "/";
  static String onboarding = "/onboarding";
  static String authentication = "/authentication";
  static String signinpage = "/signinpage";
  static String signuppage = "/signuppage";
  static String phonepage = "/phonepage";
  static String verifyemail = "/verifyemail";
  static String changepassword = "/changepassword";
  static String otppage = "/otppage";
  static String resetpassword = "/resetpassword";
  static String passwordresetsuccess = "/passwordresetsuccess";

  static String dashboard = "/dashboard";
  static String notification = "/notification";
  static String inboxpage = "/inboxpage";
  static String starredpage = "/starredpage";
  static String sentpage = "/sentpage";
  static String trashpage = "/trashpage";

  static String searchpage = "/searchpage";
  static String addaccountpage = "/addaccountpage";
  static String firstaddaccountpage = "/firstaddaccountpage";
  static String settingpage = "/settingpage";
  static String emaildetailspage = "/emaildetailspage";
  static String htmlemaildetailspage = "/htmlemaildetailspage";

  static String kingschatlogin = '/kingschatlogin';
  static String updateprofile = '/updateprofile';
  static String globalwebview = '/globalwebview';
}
