class Account {
    int? id;
    String? uuid;
    dynamic kcId;
    dynamic googleId;
    String? fname;
    String? lname;
    String? dob;
    String? phone;
    String? gender;
    String? authType;
    String? email;
    dynamic lwEmail;
    dynamic emailVerifiedAt;
    String? passwordToken;
    dynamic tokenExpiry;
    dynamic kcUsername;
    dynamic gmailToken;
    dynamic yahooToken;
    String? country;
    dynamic profilePicture;
    DateTime? createdAt;
    DateTime? updatedAt;

    Account({
        this.id,
        this.uuid,
        this.kcId,
        this.googleId,
        this.fname,
        this.lname,
        this.dob,
        this.phone,
        this.gender,
        this.authType,
        this.email,
        this.lwEmail,
        this.emailVerifiedAt,
        this.passwordToken,
        this.tokenExpiry,
        this.kcUsername,
        this.gmailToken,
        this.yahooToken,
        this.country,
        this.profilePicture,
        this.createdAt,
        this.updatedAt,
    });

    factory Account.fromJson(Map<String, dynamic> json) => Account(
        id: json["id"],
        uuid: json["uuid"],
        kcId: json["kc_id"],
        googleId: json["google_id"],
        fname: json["fname"],
        lname: json["lname"],
        dob: json["dob"],
        phone: json["phone"],
        gender: json["gender"],
        authType: json["auth_type"],
        email: json["email"],
        lwEmail: json["lw_email"],
        emailVerifiedAt: json["email_verified_at"],
        passwordToken: json["password_token"],
        tokenExpiry: json["token_expiry"],
        kcUsername: json["kc_username"],
        gmailToken: json["gmail_token"],
        yahooToken: json["yahoo_token"],
        country: json["country"],
        profilePicture: json["profile_picture"],
        createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "uuid": uuid,
        "kc_id": kcId,
        "google_id": googleId,
        "fname": fname,
        "lname": lname,
        "dob": dob,
        "phone": phone,
        "gender": gender,
        "auth_type": authType,
        "email": email,
        "lw_email": lwEmail,
        "email_verified_at": emailVerifiedAt,
        "password_token": passwordToken,
        "token_expiry": tokenExpiry,
        "kc_username": kcUsername,
        "gmail_token": gmailToken,
        "yahoo_token": yahooToken,
        "country": country,
        "profile_picture": profilePicture,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
    };
}