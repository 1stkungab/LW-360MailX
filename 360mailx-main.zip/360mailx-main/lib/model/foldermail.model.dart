class FolderMail {
  final int? id;
  final String? subject;
  final String? from;
  final String? from_name;
  final String? to;
  final String? date;

  FolderMail({
    this.id,
    this.subject,
    this.from,
    this.from_name,
    this.to,
    this.date,
  });

  // factory FolderMail.fromJson(Map<String, dynamic> json) {
  //   return FolderMail(
  //     id: json['id'] as int?,
  //     subject: json['subject'] as String?,
  //     from: json['from'] as String?,
  //     fromName: "${json['from_name']}" as String?,
  //     to: json['to'] as String?,
  //     date: json['date'] as String?,
  //   );
  // }

  factory FolderMail.fromJson(Map<String, dynamic> json) {
  return FolderMail(
    id: json['id'] as int?,
    subject: json['subject'] as String?,
    from: json['from'] as String?,
    from_name: json['from_name']?.toString(), // Ensures it's a string
    to: json['to'] is String ? json['to'] : "", // Converts false or null to an empty string
    date: json['date'] as String?,
  );
}


  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'subject': subject,
      'from': from,
      'from_name': from_name,
      'to': to,
      'date': date,
    };
  }
}
