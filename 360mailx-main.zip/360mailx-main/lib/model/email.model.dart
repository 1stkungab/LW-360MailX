class EmailAccount {
  final int id;
  final String userId;
  final String mailServiceId;
  final String accountName;
  final String accountEmail;
  final DateTime createdAt;
  final DateTime updatedAt;
  final MailService mailService;

  EmailAccount({
    required this.id,
    required this.userId,
    required this.mailServiceId,
    required this.accountName,
    required this.accountEmail,
    required this.createdAt,
    required this.updatedAt,
    required this.mailService,
  });

  factory EmailAccount.fromJson(Map<String, dynamic> json) {
    return EmailAccount(
      id: json['id'],
      userId: json['user_id'],
      mailServiceId: json['mail_service_id'],
      accountName: json['account_name'],
      accountEmail: json['account_email'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      mailService: MailService.fromJson(json['mail_service']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'mail_service_id': mailServiceId,
      'account_name': accountName,
      'account_email': accountEmail,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
      'mail_service': mailService.toJson(),
    };
  }
}

class MailService {
  final int id;
  final String name;
  final String? image;
  final DateTime createdAt;
  final DateTime updatedAt;

  MailService({
    required this.id,
    required this.name,
    this.image,
    required this.createdAt,
    required this.updatedAt,
  });

  factory MailService.fromJson(Map<String, dynamic> json) {
    return MailService(
      id: json['id'],
      name: json['name'],
      image: json['image'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'image': image,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }
}
