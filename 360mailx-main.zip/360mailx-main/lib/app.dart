import 'package:flutter/material.dart';
import 'package:loveworld_mail/constant/authstate.dart';
import 'package:loveworld_mail/helper/deeplink.helper.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';

import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

class AppInitializer {
  final BuildContext context;
  final DeepLinkHandler _deepLinkHandler = DeepLinkHandler();

  AppInitializer(this.context);

  Future<void> initialize() async {
    if (context.mounted) {
      
      AUTHENTICATIONSTATEENUM accountState = await context.read<AuthProvider>().validateAuthentication(context);
      
      await Future.delayed(const Duration(seconds: 1));
      
      switch (accountState) {
        case AUTHENTICATIONSTATEENUM.ONBOARDING:
          context.go(AppRoutes.onboarding);
          break;
        case AUTHENTICATIONSTATEENUM.LOGIN:
          context.go(AppRoutes.authentication);
          break;
        case AUTHENTICATIONSTATEENUM.DASHBOARD:
          await loadAppData();
          context.go(AppRoutes.inboxpage);
          break;
      }
    }
  }

    Future<void> loadAppData() async {
    await Future.wait([
      context.read<MailsProvider>().fetchEmailAccounts(),
      // context.read<MailsProvider>().fetchFolders(4),

    ]);

    _deepLinkHandler.initDeepLinks();
  }

  void dispose() {
    _deepLinkHandler.dispose();
  }
}
