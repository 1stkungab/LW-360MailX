import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:loveworld_mail/app.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/config/style.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  late final AppInitializer _appInitializer;

  @override
  void initState() {
    super.initState();
    _appInitializer = AppInitializer(context);
    _appInitializer.initialize();
  }

  @override
  void dispose() {
    super.dispose();
    _appInitializer.dispose();
  }

  @override
  Widget build(BuildContext context) {
    AppTextStyles.init(context);
    AppSize().init(context);
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            BounceInDown(
              child: SizedBox(
                height: 100,
                width: 100,
                child: Image(image: AssetImage(AppAssets.splashLogo)),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            // loveworldText(context)
          ],
        ),
      ),
    );
  }
}
