import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/app.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:loveworld_mail/utilities/logger.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:http/http.dart' as http;

// String randomDeviceId = "hdnkjha";

class KingsChatLogin extends StatefulWidget {
  const KingsChatLogin({
    super.key, required this.randomDeviceId
  });
  final String randomDeviceId;

  @override
  State<KingsChatLogin> createState() => _KingsChatLoginState();
}

class _KingsChatLoginState extends State<KingsChatLogin> {
  late WebViewController controller;

  String callbackUrl = "https://app.360mailx.com/api/kingsChat/callback";
  String kingschat ="https://accounts.kingsch.at/?client_id=com.kingschat&scopes=[%22conference_calls%22]&post_redirect=true&redirect_uri=https://app.360mailx.com/api/kingsChat/callback";
  String profileUrl = "https://app.360mailx.com/api/kingschat";
  // Map payload = {"device": randomDeviceId};

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
            logger.e("inprogress---");
          },
          onPageStarted: (String url) {
            logger.e("started... $url");
          },
          onPageFinished: (String url) async {
            logger.e("finished $url");

            // if (url == callbackUrl) {
            //     controller.runJavaScriptReturningResult("document.documentElement.outerHTML").then((result) {
            //     logger.i("Current page content: $result");
            //   });
            // }

            if (url == "$callbackUrl/${widget.randomDeviceId}") {
              await _fetchRedirectContent(profileUrl, {"device": widget.randomDeviceId});
            }
            //   controller
            //       .runJavaScriptReturningResult(
            //           "document.querySelector('pre').innerText")
            //       .then((result) {
            //     var formatedObject = jsonDecode(result.toString());
            //     logger.i("Page content: ${formatedObject['token']}");

            // context
            //     .read<AuthProvider>()
            //     .signinWithKC(formatedObject)
            //     .then((completed) async {
            //   final appInitializer = AppInitializer(context);
            //   await appInitializer.loadAppData();
            //   locator<ToastService>().showToast("Login Succesful");
            //   locator<GoRouter>().go(AppRoutes.inboxpage);
            // });
            //   });
            // }
          },
          onUrlChange: (change) {},
          onHttpAuthRequest: (data) {},
          onHttpError: (HttpResponseError error) {},
          onWebResourceError: (WebResourceError error) {},
          onNavigationRequest: (NavigationRequest request) async {
            logger.e("Navigation request");

            // String callbackUrl = "https://app.360mailx.com/api/kingsChat/callback";
            // if (request.url.startsWith(callbackUrl)) {
            //   await _fetchRedirectContent(profileUrl, payload);
            //   return NavigationDecision.prevent; // Prevent navigation
            // }

            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse("$kingschat/${widget.randomDeviceId}"));
  }

  Future<void> _fetchRedirectContent(String url, Map payload) async {
    try {
      final response = await http.post(Uri.parse(url), body: payload);
      if (response.statusCode == 200) {
        context.read<AuthProvider>().signinWithKC(json.decode(response.body)).then((completed) async {
          final appInitializer = AppInitializer(context);
          await appInitializer.loadAppData();
          locator<ToastService>().showToast("Login Succesful");
          locator<GoRouter>().go(AppRoutes.inboxpage);
        });

        logger.e("Redirected Content: ${response.body}");
      } else {
        logger.e(
            "Failed to load content: ${response.statusCode} ${url} ${payload} ${response}");
      }
    } catch (e) {
      logger.e("Error fetching content: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('WebView Example'),
      ),
      body: WebViewWidget(controller: controller),
    );
  }
}
