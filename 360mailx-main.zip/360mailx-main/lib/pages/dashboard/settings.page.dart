import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/model/account.model.dart';
import 'package:loveworld_mail/model/email.model.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/profile.icon.card.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:provider/provider.dart';

class SettingPage extends StatefulWidget {
  const SettingPage({super.key});

  @override
  State<SettingPage> createState() => _SettingPageState();
}

class _SettingPageState extends State<SettingPage> {
  @override
  Widget build(BuildContext context) {
    Account? account = context.watch<AuthProvider>().userdata;
    List<EmailAccount> emails = context.read<MailsProvider>().emailaccounts;

    return Scaffold(
      appBar: customAppBar(
        context,
        title: "Settings",
        action: () {},
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            seperator('ACCOUNT'),
            GestureDetector(
              onTap: () {
                if (account != null) {
                  context.read<AuthProvider>().gotoprofile();
                }
              },
              child: Container(
                padding: EdgeInsets.symmetric(
                    horizontal: AppSize.width(3), vertical: AppSize.width(2)),
                decoration: BoxDecoration(
                    color: Theme.of(context).secondaryHeaderColor,
                    borderRadius: BorderRadius.circular(10)),
                child: Row(
                  children: [
                    // ProfilePictureCard(
                    //   size: 10,
                    // ),
                    ProfileIconCard(),
                    SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          account == null
                              ? 'Anonymous'
                              : "${account.fname ?? ""} ${account.lname ?? ""}",
                          style: TextStyle(fontSize: 16),
                        ),
                        Text(
                          account == null ? '' : '${account.email}',
                          style: TextStyle(color: Colors.grey),
                        )
                      ],
                    ),
                    Expanded(child: SizedBox()),
                    Icon(Icons.arrow_forward_ios, size: 17)
                  ],
                ),
              ),
            ),
            seperator('GENERAL'),
            Container(
              padding: EdgeInsets.symmetric(
                  horizontal: AppSize.width(3), vertical: AppSize.width(3)),
              decoration: BoxDecoration(
                  color: Theme.of(context).secondaryHeaderColor,
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                children: [
                  GestureDetector(
                    onTap: () {
                      context.push(AppRoutes.globalwebview, extra: {
                        'title': 'Data & Privacy',
                        'link': 'https://360mailx.com/privacy.php'
                      });
                    },
                    child: Container(
                      color: Theme.of(context).secondaryHeaderColor,
                      child: Row(
                        children: [
                          Icon(Icons.privacy_tip),
                          SizedBox(width: 10),
                          Text(
                            'Data & Privacy',
                            style: TextStyle(fontSize: 16),
                          ),
                          Expanded(child: SizedBox()),
                          Icon(Icons.arrow_forward_ios,
                              size: 17, color: Colors.grey)
                        ],
                      ),
                    ),
                  ),
                  Divider(
                    height: 30,
                  ),
                  // GestureDetector(
                  //   onTap: (){
                  //     //  _showAboutModal(context);
                  //   },
                  //   child: Row(
                  //     children: [
                  //       Icon(Icons.security_update_good),
                  //       SizedBox(width: 10),
                  //       Text(
                  //         'Security',
                  //         style: TextStyle(fontSize: 16),
                  //       ),
                  //       Expanded(child: SizedBox()),
                  //       Icon(
                  //         Icons.arrow_forward_ios,
                  //         size: 17,
                  //         color: Colors.grey,
                  //       )
                  //     ],
                  //   ),
                  // ),
                  // Divider(height: 30),
                  GestureDetector(
                    onTap: () {
                      _showAboutModal(context);
                    },
                    child: Container(
                      child: Row(
                        children: [
                          Icon(Icons.info_outline_rounded),
                          SizedBox(width: 10),
                          Text(
                            'About 360Mailx',
                            style: TextStyle(fontSize: 16),
                          ),
                          Expanded(child: SizedBox()),
                          Icon(
                            Icons.arrow_forward_ios,
                            size: 17,
                            color: Colors.grey,
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // seperator('NOTIFICATIONS'),
            seperator('EMAIL ACCOUNTS'),
            // ...List.generate(emails.length, (index){
            //   EmailAccount accountInstance = emails[index];
            //   return GestureDetector(
            //     onTap: () async {
            //       print(accountInstance.id);
            //       await context.read<MailsProvider>().selectDifferentAccount(accountInstance.id);
            //     },
            //     child: Container(
            //     child: Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //       children: [
            //         Row(
            //           children: [
            //             Container(
            //               child: Row(
            //                 mainAxisAlignment: MainAxisAlignment.center,
            //                 crossAxisAlignment: CrossAxisAlignment.center,
            //                 children: [
            //                   Text(accountInstance.accountName.split('').first),
            //                 ],
            //               ),
            //               width: 40,
            //               height:  40,
            //               decoration: BoxDecoration(
            //                 color: Theme.of(context).secondaryHeaderColor,
            //                 borderRadius: BorderRadius.circular(100)
            //               ),
            //             )
            //            ,
            //            SizedBox(width: 20),
            //            Column(
            //             crossAxisAlignment: CrossAxisAlignment.start,
            //             children: [
            //                Text(accountInstance.accountName, style: TextStyle(fontWeight: FontWeight.w600),),
            //                Text(accountInstance.accountEmail, style: TextStyle(color: Colors.grey)),
            //             ],
            //            )
            //           ],
            //         ),

            //         Icon(Icons.check_circle, color: context.watch<MailsProvider>().activeAccountid == accountInstance.id ? Colors.green : Colors.transparent)
            //       ],
            //     ),
            //     margin: EdgeInsets.only(
            //       bottom: 15
            //     ),
            //                 ),
            //   ); })

            Expanded(
              child: Container(
                child: ListView(
                  children: List.generate(emails.length, (index) {
                    EmailAccount accountInstance = emails[index];
                    return Dismissible(
                      key: Key("${accountInstance.id}"), // Unique key
                      direction:
                          DismissDirection.endToStart, // Swipe from right to left
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: Icon(Icons.delete, color: Colors.white),
                      ),
                      onDismissed: (direction) async {
                        await context.read<MailsProvider>().deleteMailAccount(index, {"account_id": accountInstance.id});
                      },
                      child: GestureDetector(
                        onTap: () async {
                          print(accountInstance.id);
                          await context
                              .read<MailsProvider>()
                              .selectDifferentAccount(accountInstance.id);
                        },
                        child: Container(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Text(accountInstance.accountName
                                            .split('')
                                            .first),
                                      ],
                                    ),
                                    width: 40,
                                    height: 40,
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).secondaryHeaderColor,
                                      borderRadius: BorderRadius.circular(100),
                                    ),
                                  ),
                                  SizedBox(width: 20),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        accountInstance.accountName,
                                        style:
                                            TextStyle(fontWeight: FontWeight.w600),
                                      ),
                                      Text(
                                        accountInstance.accountEmail,
                                        style: TextStyle(color: Colors.grey),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              Icon(
                                Icons.check_circle,
                                color: context
                                            .watch<MailsProvider>()
                                            .activeAccountid ==
                                        accountInstance.id
                                    ? Colors.green
                                    : Colors.transparent,
                              ),
                            ],
                          ),
                          margin: EdgeInsets.only(bottom: 15),
                        ),
                      ),
                    );
                  }),
                ),
              ),
            )

            // Container(
            //   padding: EdgeInsets.symmetric(
            //       horizontal: AppSize.width(3), vertical: AppSize.width(3)),
            //   decoration: BoxDecoration(
            //       color: Theme.of(context).secondaryHeaderColor,
            //       borderRadius: BorderRadius.circular(10)),
            //   child: const Column(
            //     children: [
            //       Row(
            //         children: [
            //           Icon(Icons.notifications),
            //           SizedBox(width: 10),
            //           Text(
            //             'Email notifications',
            //             style: TextStyle(fontSize: 16),
            //           ),
            //           Expanded(child: SizedBox()),
            //           Icon(Icons.arrow_forward_ios,
            //               size: 17, color: Colors.grey)
            //         ],
            //       ),
            //     ],
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Column seperator(title) {
    return Column(
      children: [
        SizedBox(height: AppSize.height(3)),
        Text(title),
        const SizedBox(height: 10),
      ],
    );
  }
}

void _showAboutModal(BuildContext context) {
  showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    backgroundColor: Colors.white,
    isScrollControlled: true,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "360MailX",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.blueAccent,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "About App",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  color: Colors.black87,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "360MailX is a modern, secure, and intuitive email management tool designed to simplify your communication.\n\n"
                "Our product provides a seamless experience across devices, combining robust features like advanced search, email management, productivity tools, security, customization, and integration.\n\n"
                "Built with user privacy and security in mind, 360MailX ensures your data is safe while empowering you to manage your inbox effortlessly.\n\n"
                "Whether you’re an individual or a professional, 360MailX adapts to your needs, helping you stay organized, effective, and productive.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.black87),
              ),
              SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  padding: EdgeInsets.all(4),
                  decoration: BoxDecoration(
                      border: Border.all(width: 1),
                      borderRadius: BorderRadius.circular(100)),
                  child: Icon(Icons.close),
                ),
              )
            ],
          ),
        ),
      );
    },
  );
}
