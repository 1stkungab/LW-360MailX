import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/pages/widgets/appfield.widget.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:provider/provider.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    ValueNotifier<bool> isLoading = ValueNotifier<bool>(false);

    return Scaffold(
      appBar: customAppBar(
        context,
        title: "Profile",
        action: () {},
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: AppSize.height(2)),
              Row(
                children: [
                  Expanded(
                    child: AppField(
                      fieldController: firstnameController,
                      label: "Firstname",
                      hint: "Enter firstname",
                      type: TextInputType.visiblePassword,
                      maxLine: 1,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppField(
                      fieldController: lastnameController,
                      label: "Lastname",
                      hint: "Enter lastname",
                      type: TextInputType.visiblePassword,
                      maxLine: 1,
                    ),
                  ),
                ],
              ),
              SizedBox(height: AppSize.height(2)),
              AppField(
                fieldController: emailController,
                label: "Email",
                hint: "Enter email",
                readOnly: true,
                type: TextInputType.emailAddress,
              ),
              SizedBox(height: AppSize.height(2)),
              AppField(
                fieldController: phoneController,
                label: "Phone",
                hint: "Enter phons",
                type: TextInputType.name,
              ),
              SizedBox(height: AppSize.height(2)),
              Row(
                children: [
                  Expanded(
                    child: AppField(
                      fieldController: startDateController,
                      label: "DOB",
                      hint: "Date of Birth",
                      type: TextInputType.number,
                      readOnly: true,
                      onTap: () {
                        // selectDate(context, startDateController);
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: AppField(
                      fieldController: genderController,
                      label: "Gender",
                      hint: "Gender",
                      readOnly: true,
                      onTap: () {
                        // showRoundedAlertDialog(
                        //   context,
                        //   onSelectGender: (selectedGender) {
                        //     genderController.text = gender[selectedGender];
                        //     selected.value = selectedGender;
                        //   },
                        // );
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(height: AppSize.height(5)),
              ValueListenableBuilder<bool>(
                  valueListenable: isLoading,
                  builder: (context, _, snapshot) {
                    return AppButton(
                        isPrimary: true,
                        isLoading: isLoading.value,
                        title: "Update Profile",
                        onPressed: () async {
                          Map<String, dynamic> payload = {
                            "uuid": "111111",
                            "fname": firstnameController.text,
                            "lname": lastnameController.text,
                            "email": emailController.text,
                            "phone": phoneController.text,
                            "dob": startDateController.text,
                            "country": "Nigeria",
                            "gender": genderController.text
                          };

                          await context
                              .read<AuthProvider>()
                              .updateProfile(payload)
                              .then((completed) {
                            if (completed) {
                              locator<GoRouter>().go(AppRoutes.inboxpage);
                            }
                          });

                          isLoading.value = false;
                        });
                  }),
            ],
          ),
        ),
      ),
    );
  }

  Column seperator(title) {
    return Column(
      children: [
        SizedBox(height: AppSize.height(3)),
        Text(title),
        const SizedBox(height: 10),
      ],
    );
  }
}
