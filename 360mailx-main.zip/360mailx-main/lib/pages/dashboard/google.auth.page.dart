import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class StatefulWebView extends StatefulWidget {

  const StatefulWebView({super.key});

  @override
  State<StatefulWebView> createState() => _StatefulWebViewState();
}

class _StatefulWebViewState extends State<StatefulWebView> {
  late WebViewController controller;

  String backup = 'https://flutter.dev';
  List<String> data = ["https://app.360mailx.com/api/google/signin", "https://www.youtube.com/shorts/48M-43xy-Nc", "https://www.youtube.com/live/zEQpT4N_dB0?si=2mabmka9ghq1bF74"];

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
          },
          onPageStarted: (String url) {},
          onPageFinished: (String url) {},
          onHttpError: (HttpResponseError error) {},
          onWebResourceError: (WebResourceError error) {},
          onNavigationRequest: (NavigationRequest request) {
            // if (!request.url.startsWith('https://www.youtube.com/')) {
            //   return NavigationDecision.prevent;
            // }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(data[0]));
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text('WebView Example'),
      ),
      body: WebViewWidget(controller: controller),
    );
  }
}
