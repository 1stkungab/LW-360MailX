import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/constant.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/newemail.widget.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/utilities/loader.dart';
import 'package:loveworld_mail/utilities/logger.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';

class HtmlEmailDetailsPage extends StatefulWidget {
  const HtmlEmailDetailsPage({super.key});

  @override
  State<HtmlEmailDetailsPage> createState() => _HtmlEmailDetailsPageState();
}

class _HtmlEmailDetailsPageState extends State<HtmlEmailDetailsPage> {
  late final WebViewController _controller;

  InAppWebViewController? _webViewController;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    // Listen for changes in mailbody and load it into WebView
    final mailsProvider = context.watch<MailsProvider>();
    if (mailsProvider.mailbody.isNotEmpty) {
      _controller.loadHtmlString(mailsProvider.mailbody);
    }
  }

  @override
  Widget build(BuildContext context) {
    FolderMail selectedMail = context.watch<MailsProvider>().selectedMail!;
    String mailbody = context.watch<MailsProvider>().mailbody;

    bool isHtml(String text) {
      final htmlTagRegExp = RegExp(r"<[a-z][\s\S]*>", caseSensitive: false);
      return htmlTagRegExp.hasMatch(text);
    }

//     _controller.runJavaScript('''
//   var style = document.createElement('style');
//   style.innerHTML = "body { background-color: lightgrey; font-family: Arial, sans-serif; }";
//   document.head.appendChild(style);
// ''');

    return Scaffold(
      appBar: customAppBar(context, title: "", isMain: false, action: () {}),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: AppSize.height(1)),
              Row(
                children: [
                  Expanded(
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: "${selectedMail.subject}",
                            style: TextStyle(
                                fontSize: 20,
                                color: Theme.of(context)
                                    .textTheme
                                    .bodyLarge!
                                    .color,
                                height: 1.5),
                          ),
                          WidgetSpan(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 1),
                              decoration: BoxDecoration(
                                border:
                                    Border.all(width: 1, color: Colors.grey),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text(
                                "Inbox",
                                style: TextStyle(fontSize: 12),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: AppSize.height(2)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      // ProfilePictureCard(
                      //   size: 10,
                      // ),
                      CircleAvatar(
                        radius: 25,
                        backgroundColor: Theme.of(context).secondaryHeaderColor,
                        child: Text(
                          selectedMail.from_name![0],
                          style: const TextStyle(color: Colors.black54),
                        ),
                      ),
                      SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "${selectedMail.from_name}",
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                          //  Text(
                          //   "${selectedMail.from!.split("@").first}",
                          //   style: TextStyle(fontWeight: FontWeight.w600),
                          // ),
                          Text(selectedMail.from ?? "",
                              style: TextStyle(
                                  fontWeight: FontWeight.w300,
                                  color: Colors.grey))
                        ],
                      ),
                    ],
                  ),
                  GestureDetector(
                    onTap: () {
                      String from = selectedMail.from ?? "";
                      String subject = selectedMail.subject ?? "";

                      toController.text = from;
                      subjectController.text =
                          subject.contains("Re:") ? subject : "Re: $subject";
                      showAnimatedModalSheet(context);
                    },
                    child: Container(
                      margin: EdgeInsets.symmetric(vertical: 10),
                      padding: EdgeInsets.all(4),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(
                              width: 1,
                              color: Theme.of(context)
                                  .textTheme
                                  .bodyLarge!
                                  .color!)),
                      child: Text('Reply'),
                    ),
                  )
                ],
              ),
              SizedBox(height: AppSize.height(2)),

              // WebView to Render Email Body
              mailbody != rendering
                  ? isHtml(mailbody)
                      ? Container(
                          child: HtmlWidget(
                          mailbody,
                          customStylesBuilder: (element) {
                            if (element.classes.contains('foo')) {
                              return {'color': 'red'};
                            }
                            return null;
                          },
                          customWidgetBuilder: (element) {
                            if (element.attributes['foo'] == 'bar') {
                              // render a custom block widget that takes the full width
                              return Container();
                            }

                            if (element.attributes['fizz'] == 'buzz') {
                              // render a custom widget inline with surrounding text
                              return InlineCustomWidget(child: Container());
                            }

                            return null;
                          },
                          renderMode: RenderMode.column,
                          textStyle: TextStyle(fontSize: 14),
                        ))

                      //  Container(
                      //     height: AppSize.height(58),
                      //     width: double.infinity,
                      //     child: WebViewWidget(controller: _controller),
                      //   )
                      : Container(
                          height: AppSize.height(58),
                          child: Center(child: Text(mailbody)),
                        )
                  : Container(
                      height: AppSize.height(58),
                      child: Center(child: fetchLoader(20.0)),
                    ),

              // Row(
              //   children: [
              //     GestureDetector(
              //       onTap: () {
              //         String from = selectedMail.from ?? "";
              //         String subject = selectedMail.subject ?? "";

              //         toController.text = from;
              //         subjectController.text =
              //             subject.contains("Re:") ? subject : "Re: $subject";
              //         showAnimatedModalSheet(context);
              //       },
              //       child: Container(
              //         margin: EdgeInsets.symmetric(vertical: 10),
              //         padding: EdgeInsets.all(4),
              //         decoration: BoxDecoration(
              //             borderRadius: BorderRadius.circular(5),
              //             border: Border.all(
              //                 width: 1,
              //                 color: Theme.of(context)
              //                     .textTheme
              //                     .bodyLarge!
              //                     .color!)),
              //         child: Text('Reply'),
              //       ),
              //     )
              //   ],
              // )
            ],
          ),
        ),
      ),
    );
  }
}
