import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/components/search.component.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/model/email.model.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/inboxMailCard.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/utilities/toast.service.dart';
import 'package:provider/provider.dart';

class InboxPage extends StatefulWidget {
  const InboxPage({super.key});

  @override
  State<InboxPage> createState() => _InboxPageState();
}

class _InboxPageState extends State<InboxPage> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    // Defer fetchData to after the first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        if(context.read<MailsProvider>().emailaccounts.length == 0){
          // context.go(AppRoutes.addaccountpage);
        }else{
        context.read<MailsProvider>().fetchData(first: true);
        }
      }
    });

    // Set up scroll listener
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        context.read<MailsProvider>().fetchData();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // List<Map<String, dynamic>> data = context.watch<MailsProvider>().data;
    bool isLoading = context.watch<MailsProvider>().isLoading;
    bool isFetching = context.watch<MailsProvider>().isFetching;
    List<FolderMail> inboxs = context.watch<MailsProvider>().tempFolderMail;

    List<EmailAccount> account = context.watch<MailsProvider>().emailaccounts;

    return Scaffold(
      appBar: customAppBar(context, action: () {
        
        //
        
      }),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: AppSize.width(3),
              left: AppSize.width(5),
              right: AppSize.width(5),
              bottom: AppSize.width(3),
            ),
            child: searchComponent(context, inboxs, 'inbox'),
          ),
          Expanded(
            child: account.isEmpty ? Column(

             
              children: [
                 SizedBox(height: AppSize.width(40)),
                SizedBox(
                  width: AppSize.width(50),
                  child: Image(image: AssetImage(AppAssets.emptymail))),
                Text("No Email Activated", style: TextStyle(fontSize: 16),),
                SizedBox(height: 10),
                SizedBox(
                  width: AppSize.width(50),
                  child: GestureDetector(
                    onTap: (){
                      context.push(AppRoutes.addaccountpage);
                    },
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        vertical: 12
                      ),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Theme.of(context).primaryColor
                      ),
                      child: Text( "Add Mail +", textAlign: TextAlign.center, style: TextStyle(color: Colors.white))))
                  // AppButton(
                  //   title: "Add Mail +",
                  //   isPrimary: true,
                  //   onPressed: (){},
                  // ),
                )
              ],
            ) :
            
            ListView.builder(
              controller: _scrollController,
              itemCount: inboxs.length + 1, // Add 1 for the loader at the end
              itemBuilder: (context, index) {
                if (index == inboxs.length) {
                  return fetchLoader(isLoading);
                }
                // Display data item
                final item = inboxs[index];
                return SlideInRight(
                  child: Dismissible(
                    key: Key("${item.id}"), // Use a unique key
                    direction:
                        DismissDirection.endToStart, // Swipe from right to left
                    onDismissed: (direction) {
                      // Call delete function when dismissed
                      context.read<MailsProvider>().deleteItem(index, 'inbox');
                      ToastUtil().showToast("${item.subject} Moved to trash");
                    },
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    child: InboxMailCard(item: item, label: 'inbox',),
                  ),
                );
              },
            ),
          ),
          fetchLoader(isFetching)
        ],
      ),
    );
  }
}

fetchLoader(state) {
  if (state) {
    return const Padding(
      padding: EdgeInsets.all(5.0),
      child: Center(
          child: SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
              ))),
    );
  } else {
    return const SizedBox();
  }
}
