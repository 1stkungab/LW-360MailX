import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/components/search.component.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/mail.card.dart';
import 'package:loveworld_mail/pages/widgets/newemail.widget.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/utilities/toast.service.dart';
import 'package:provider/provider.dart';

class InboxPage extends StatefulWidget {
  const InboxPage({super.key});

  @override
  State<InboxPage> createState() => _InboxPageState();
}

class _InboxPageState extends State<InboxPage> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    // Defer fetchData to after the first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        if(context.read<MailsProvider>().emailaccounts.length == 0){
          // context.go(AppRoutes.addaccountpage);
        }else{
        context.read<MailsProvider>().fetchData(first: true);
        }
      }
    });

    // Set up scroll listener
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        context.read<MailsProvider>().fetchData();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> data = context.watch<MailsProvider>().data;
    bool isLoading = context.watch<MailsProvider>().isLoading;
    bool isFetching = context.watch<MailsProvider>().isFetching;

    return Scaffold(
      appBar: customAppBar(context, action: () {
        //
      }),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(
              top: AppSize.width(3),
              left: AppSize.width(5),
              right: AppSize.width(5),
              bottom: AppSize.width(3),
            ),
          // child: searchComponent(context, data, 'inbox'),
          ),
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              itemCount: data.length + 1, // Add 1 for the loader at the end
              itemBuilder: (context, index) {
                if (index == data.length) {
                  return fetchLoader(isLoading);
                }
                // Display data item
                final item = data[index];
                return SlideInRight(
                  child: Dismissible(
                    key: Key(item['sender']), // Use a unique key
                    direction:
                        DismissDirection.endToStart, // Swipe from right to left
                    onDismissed: (direction) {
                      // Call delete function when dismissed
                      // context.read<MailsProvider>().deleteItem(index);
                      ToastUtil().showToast("${item['sender']} Moved to trash");
                    },
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    child: MailCard(item: item),
                  ),
                );
              },
            ),
          ),
          fetchLoader(isFetching)
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () {
          showAnimatedModalSheet(context);
        },
        child: const Icon(Icons.edit, color: Colors.white),
      ),
    );
  }
}

fetchLoader(state) {
  if (state) {
    return const Padding(
      padding: EdgeInsets.all(5.0),
      child: Center(
          child: SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
              ))),
    );
  } else {
    return const SizedBox();
  }
}
