import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/utilities/logger.dart';
import 'package:webview_flutter/webview_flutter.dart';

class GlobalWebView extends StatefulWidget {
  const GlobalWebView({super.key, required this.link, required this.title,});
  final String link;
  final String title;

  @override
  State<GlobalWebView> createState() => _GlobalWebViewState();
}

class _GlobalWebViewState extends State<GlobalWebView> {
  late WebViewController controller;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            // Update loading bar.
             logger.e("inprogress--- ${widget.link}");
          },
          onPageStarted: (String url) {
             logger.e("started...");
          },
          onPageFinished: (String url) {
            logger.e("finished $url");
            //  locator<GoRouter>().go(AppRoutes.inboxpage);
          },
          onHttpError: (HttpResponseError error) {},
          onWebResourceError: (WebResourceError error) {},
          onNavigationRequest: (NavigationRequest request) {
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.link));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: WebViewWidget(controller: controller),
    );
  }
}
