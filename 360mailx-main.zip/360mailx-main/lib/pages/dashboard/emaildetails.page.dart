import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/newemail.widget.dart';
import 'package:loveworld_mail/pages/widgets/profilepicture.widget.dart';

class EmailDetailsPage extends StatefulWidget {
  const EmailDetailsPage({super.key});

  @override
  State<EmailDetailsPage> createState() => _EmailDetailsPageState();
}

class _EmailDetailsPageState extends State<EmailDetailsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(context, title: "", isMain: false, action: () {}),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: AppSize.height(1)),
              Row(
                children: [
                  Expanded(
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text:
                                "Just a few taps and your light's on! bringing you the best offer ",
                            style: TextStyle(
                                fontSize: 20,
                                color: Theme.of(context)
                                    .textTheme
                                    .bodyLarge!
                                    .color,
                                height: 1.5),
                          ),
                          WidgetSpan(
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 1),
                              decoration: BoxDecoration(
                                border:
                                    Border.all(width: 1, color: Colors.grey),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text(
                                "Inbox",
                                style: TextStyle(fontSize: 12),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: AppSize.height(2)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Row(
                    children: [
                      ProfilePictureCard(
                        size: 10,
                      ),
                      SizedBox(width: 12),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Techsetup",
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                          Text("to me",
                              style: TextStyle(
                                  fontWeight: FontWeight.w300,
                                  color: Colors.grey))
                        ],
                      ),
                    ],
                  ),
                  GestureDetector(
                      onTap: () {
                        toController.text = "Techsetup";

                        // showAnimatedModalSheet(context);
                      },
                      child: const Icon(Icons.reply))
                ],
              ),
              SizedBox(height: AppSize.height(2)),
              const Text(""" Dear Williams,
          
          We are excited to share with you something that’s going to make your day brighter! Imagine having complete control over your lighting system, effortlessly adjusting the ambiance of your space with just a few taps. At [Your Company Name], we understand the importance of convenience and comfort, and we’re here to bring you the best offer yet.
          
          Your Convenience is Our Priority We know how important it is for you to have control at your fingertips, especially when it comes to creating the perfect lighting environment. Whether you’re hosting a gathering, enjoying a quiet evening, or simply winding down after a busy day, our advanced lighting solutions give you the flexibility to set the right mood for any occasion.
          
          No more fiddling with light switches or remembering which setting works best. Our smart system makes it all happen automatically, ensuring that your lights are always in sync with your needs. With just a few taps, you’ll be able to switch on your lights, adjust their brightness, change the color temperature, or set up pre-defined lighting scenes tailored just for you. The best part? You can control all of this from the palm of your hand using our intuitive mobile app.
          
          Introducing Our Latest Offer As part of our ongoing commitment to enhancing your experience, we’re bringing you an exclusive offer that you won’t want to miss. For a limited time, we’re offering:
          
          Up to 30% off on all smart lighting products
          Free shipping on your first order
          Exclusive access to our VIP customer support service
          That’s right! You can now make your home smarter and more efficient without breaking the bank. Take advantage of this special offer, and enjoy seamless, personalized lighting that adapts to your lifestyle.
          
          Why Choose Our Smart Lighting? Our lighting products are more than just light bulbs. Here’s what sets us apart:
          
          Energy Efficiency: Save on your electricity bills by switching to our energy-efficient LED lighting, designed to use less power while providing the same brightness.
          Smart Features: Integration with popular smart home platforms like Alexa, Google Assistant, and Apple HomeKit. Voice control and automation are just a tap away.
          Customizable Scenes: Whether you want bright light for productivity or a cozy, dim setting for relaxation, you can create custom lighting scenes that match your exact preferences.
          Long-Lasting Durability: Built to last, our bulbs are designed to withstand wear and tear, providing you with reliable lighting for years to come.
          How to Redeem This Offer Redeeming your offer is simple. Just follow these easy steps:
          
          Visit our website at [Your Website Link].
          Browse through our selection of smart lighting products and add them to your cart.
          At checkout, enter the code BESTOFFER to receive your 30% discount and enjoy free shipping on your first order.
          Don’t wait! This offer is only available for a limited time, so be sure to act fast before it expires.
          
          Get in Touch with Us We’re always here to help. If you have any questions or need assistance choosing the perfect lighting setup for your home, don’t hesitate to reach out to our customer support team. You can contact us at [Customer Support Email] or call us at [Phone Number].
          
          Thank you for being a valued customer of [Your Company Name]. We look forward to helping you bring the best lighting experience into your home.""")
            ],
          ),
        ),
      ),
    );
  }
}
