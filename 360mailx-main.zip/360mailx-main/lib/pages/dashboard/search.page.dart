import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/inboxMailCard.dart';
import 'package:loveworld_mail/pages/widgets/mail.card.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:provider/provider.dart';

class SearchPage extends StatefulWidget {
  // final List<Map<String, dynamic>> mails;
  final List<FolderMail> mails;
  final String page;
  const SearchPage({super.key, required this.mails, required this.page});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _focusNode = FocusNode();
  List<FolderMail>_filteredMails = [];

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      FocusScope.of(context).requestFocus(_focusNode);
    });
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _searchController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    final mails = widget.mails;
    // final mails = context.read<MailsProvider>().data;
    setState(() {
      _filteredMails = query.isEmpty
          ? []
          : mails
              .where((mail) =>
                  mail.subject!.toLowerCase().contains(query) ||
                  mail.from_name!.toLowerCase().contains(query))
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar(context, title: "Search", isMain: false, action: () {}),
      body: Column(
        children: [
          SizedBox(height: AppSize.height(2)),
          Padding(
             padding: EdgeInsets.symmetric(horizontal: AppSize.width(4)),
            child: TextFormField(
              controller: _searchController,
              focusNode: _focusNode, // Attach the focus node here
              keyboardType: TextInputType.text,
              decoration: InputDecoration(
                prefixIcon: const Icon(
                  Icons.search_outlined,
                  color: Colors.grey,
                ),
                hintText: 'Search',
                border: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.grey, width: 1),
                  borderRadius: BorderRadius.circular(8),
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
          ),
          SizedBox(height: AppSize.height(2)),
          Expanded(
            child: _filteredMails.isEmpty
                ? const Center(child: Text('No results found'))
                : ListView.builder(
                    itemCount: _filteredMails.length,
                    itemBuilder: (BuildContext context, index) {
                      return InboxMailCard(item: _filteredMails[index], label: widget.page);
                      
                      // MailCard(item: _filteredMails[index]);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
