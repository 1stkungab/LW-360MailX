import 'dart:developer';

import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/pages/dashboard/component/CustomeField.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:provider/provider.dart';

class AddAccountPage extends StatefulWidget {
  const AddAccountPage({super.key});

  @override
  State<AddAccountPage> createState() => _AddAccountPageState();
}

class _AddAccountPageState extends State<AddAccountPage> {
  int selectedIndex = 0;

  toggle(index) {
    selectedIndex = index;
    setState(() {});
  }

  bool loading = false;

  void processing() {
    setState(() {
      loading = !loading;
    });
  }

  void _submitData() async {
    processing();

    int mail_service_id = 1;

    // Set mailServiceId based on the selected index
    switch (selectedIndex) {
      case 0:
        mail_service_id = 4;
        break;
      case 1:
        mail_service_id = 2;
        break;
      case 2:
        mail_service_id = 3;
        break;
      case 4:
        mail_service_id = 1;
        break;
      default:
        // Optional: handle other cases or set a default value
        mail_service_id = 0; // Default or error handling if needed
    }

    final data = {
      "account_email": mailController.text,
      "account_password": passController.text,
      "mail_service_id": mail_service_id,
      "incoming_server_url": incomingServerUrlController.text,
      "incoming_server_port": incomingServerPortController.text,
      "incoming_security_type": incomingSecurityTypeController.text,
      "outgoing_server_url": outgoingServerUrlController.text,
      "outgoing_server_port": outgoingServerPortController.text,
      "outgoing_security_type": outgoingSecurityTypeController.text,
      "account_name": accountNameController.text,
    };

    bool response = await context.read<MailsProvider>().addAccount(data);
    processing();

    Navigator.of(context).popUntil((route) {
      return route.settings.name == AppRoutes.inboxpage;
    });

    print("Submitted Data: $data");
  }

  void _submitGmailData(googleAuth) async {
    processing();

    bool response = await context.read<MailsProvider>().addGoogleAccount(googleAuth);
    processing();

    Navigator.of(context).popUntil((route) {
      return route.settings.name == AppRoutes.inboxpage;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Accounts",
          style: TextStyle(color: Theme.of(context).textTheme.bodyLarge!.color),
        ),
      ),
      // customAppBar(context, title: "Account", isMain: false, action: () {}),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
        child: Column(
          children: [
            SizedBox(height: AppSize.height(2)),
            accountCard(
              "LW360",
              AppAssets.loveworld,
              1,
              () {
                toggle(0);
                mailServiceIdController.text = "4";
              },
              isSelected: selectedIndex == 0,
            ),
            accountCard(
              "Gmail",
              AppAssets.google,
              2,
              () {
                toggle(1);
                mailServiceIdController.text = "2";
              },
              isSelected: selectedIndex == 1,
            ),
            accountCard(
              "Yahoo Mail",
              AppAssets.yahoo,
              3,
              () {
                toggle(2);
                mailServiceIdController.text = "3";
              },
              isSelected: selectedIndex == 2,
            ),
            // accountCard(
            //   "360MailX",
            //   AppAssets.loveworld,
            //   4,
            //   () => toggle(
            //     3,
            //   ),
            //   isSelected: selectedIndex == 3,
            // ),
            accountCard(
              "Web Mail",
              AppAssets.webmail,
              4,
              () {
                toggle(4);
                mailServiceIdController.text = "1";
              },
              isSelected: selectedIndex == 4,
            ),
            const Expanded(child: SizedBox()),
            ZoomIn(
              child: AppButton(
                title: "Continue",
                isLoading: loading,
                onPressed: () async {
                  // TRY Processing Google Login
                  if (selectedIndex == 1) {
                    processing();

                    try {
                      GoogleSignIn googleSignIn = GoogleSignIn(
                          scopes: [
                            'email',
                            'profile',
                            'https://www.googleapis.com/auth/gmail.readonly'
                          ],
                          serverClientId:
                              "1063756514541-bs2tnor69pc9q833uvfj5hkq3erou7t5.apps.googleusercontent.com");

                      // await googleSignIn.signOut();
                      // await googleSignIn.disconnect();

                      // Check if a user is signed in before disconnecting
                      GoogleSignInAccount? currentUser =
                          googleSignIn.currentUser;
                      if (currentUser != null) {
                        print('----------- ${currentUser}');
                        await googleSignIn
                            .disconnect(); // Disconnect only if signed in
                      }
                      // Sign out (extra safety)
                      await googleSignIn.signOut();

                      GoogleSignInAccount? googleAccount =
                          await googleSignIn.signIn();

                      log("this is googleAccount ${googleAccount}");

                      _submitGmailData(googleAccount);

                      processing();
                    } catch (error) {
                      processing();
                      log("this is googleAccount ${error}");
                    }

                    //    Navigator.push(
                    //   context,
                    //   MaterialPageRoute(builder: (context) => StatefulWebView()),
                    // );
                  }

                  // else if (selectedIndex == 0) {
                  //   locator<ToastService>().showToast("Coming Soon");
                  // }

                  else {
                    _showSubmitModal(context, () {
                      if (formKey.currentState!.validate()) {
                        _submitData();
                        Navigator.pop(context);
                      }
                      // _submitData();
                    });
                  }
                },
                isPrimary: true,
              ),
            ),
            const Expanded(child: SizedBox()),
          ],
        ),
      ),
    );
  }

  accountCard(String title, String path, int index, Function()? action,
      {bool isSelected = false}) {
    return SlideInUp(
      duration: Duration(milliseconds: index * 400),
      child: GestureDetector(
        onTap: action,
        child: Container(
          margin: EdgeInsets.symmetric(vertical: AppSize.width(2)),
          padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
          height: 55,
          decoration: BoxDecoration(
              border: Border.all(
                  width: 0.5,
                  color: Theme.of(context).textTheme.bodyMedium!.color!),
              borderRadius: BorderRadius.circular(10),
              color: Theme.of(context).scaffoldBackgroundColor),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Image(
                    image: AssetImage(path),
                    width: 20,
                  ),
                  const SizedBox(width: 20),
                  Text(title),
                ],
              ),
              Icon(Icons.check_circle,
                  color: isSelected ? AppColors.primary : Colors.grey)
            ],
          ),
        ),
      ),
    );
  }
}

void _showSubmitModal(BuildContext context, Function()? onClick) {
  showModalBottomSheet(
    context: context,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    backgroundColor: Colors.white,
    isScrollControlled: true,
    builder: (context) {
      double maxHeight = MediaQuery.of(context).size.height * 0.7;

      return Container(
        constraints: BoxConstraints(maxHeight: maxHeight),
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: MediaQuery.of(context).viewInsets.bottom + 16,
        ),
        child: SingleChildScrollView(
          child: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Submit Email Account",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 10),
                // _buildTextField(mailController, "Account Email",
                //     isRequired: true),
                // _buildTextField(passController, "Account Password",
                //     isPassword: true, isRequired: true),
                // // _buildTextField(mailServiceIdController, "Mail Service ID"),
                // _buildTextField(
                //     incomingServerUrlController, "Incoming Server URL"),
                // _buildTextField(
                //     incomingServerPortController, "Incoming Server Port"),
                // _buildTextField(
                //     incomingSecurityTypeController, "Incoming Security Type"),
                // _buildTextField(
                //     outgoingServerUrlController, "Outgoing Server URL"),
                // _buildTextField(
                //     outgoingServerPortController, "Outgoing Server Port"),
                // _buildTextField(
                //     outgoingSecurityTypeController, "Outgoing Security Type"),
                // _buildTextField(accountNameController, "Account Name",
                //     isRequired: true),
                CustomTextField(
                    controller: mailController,
                    label: "Account Email",
                    isRequired: true),
                CustomTextField(
                    controller: passController,
                    label: "Account Password",
                    isPassword: true,
                    isRequired: true),
                // CustomTextField(mailServiceIdController, "Mail Service ID"),
                CustomTextField(
                    controller: incomingServerUrlController,
                    label: "Incoming Server URL"),
                CustomTextField(
                    controller: incomingServerPortController,
                    label: "Incoming Server Port"),
                CustomTextField(
                    controller: incomingSecurityTypeController,
                    label: "Incoming Security Type"),
                CustomTextField(
                    controller: outgoingServerUrlController,
                    label: "Outgoing Server URL"),
                CustomTextField(
                    controller: outgoingServerPortController,
                    label: "Outgoing Server Port"),
                CustomTextField(
                    controller: outgoingSecurityTypeController,
                    label: "Outgoing Security Type"),
                CustomTextField(
                    controller: accountNameController,
                    label: "Account Name",
                    isRequired: true),

                SizedBox(height: 10),
                AppButton(
                  title: "Submit",
                  isPrimary: true,
                  onPressed: onClick,
                ),
                SizedBox(height: 120),
              ],
            ),
          ),
        ),
      );
    },
  );
}

Widget _buildTextField(TextEditingController controller, String label,
    {bool isPassword = false, bool isRequired = false}) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextFormField(
      controller: controller,
      obscureText: isPassword,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
      ),
      validator: (value) {
        if (isRequired && (value == null || value.isEmpty)) {
          return "Please enter ${label.toLowerCase()}";
        }
        return null; // Allow null values if not required
      },
    ),
  );
}
