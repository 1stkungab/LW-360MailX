import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:loveworld_mail/components/search.component.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/pages/dashboard/inbox.page.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/inboxMailCard.dart';
import 'package:loveworld_mail/pages/widgets/trashMailCard.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/utilities/toast.service.dart';
import 'package:provider/provider.dart';

class TrashPage extends StatefulWidget {
  const TrashPage({super.key});

  @override
  State<TrashPage> createState() => _TrashPageState();
}

class _TrashPageState extends State<TrashPage> {
   final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    // Defer fetchData to after the first frame
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        context.read<MailsProvider>().fetchData(first: true);
      }
    });

    // Set up scroll listener
    _scrollController.addListener(() {
      if (_scrollController.position.pixels ==
          _scrollController.position.maxScrollExtent) {
        context.read<MailsProvider>().fetchData();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // List<Map<String, dynamic>> data = context.watch<MailsProvider>().trash;
    bool isLoading = context.watch<MailsProvider>().isLoading;
    bool isFetching = context.watch<MailsProvider>().isFetching;

      List<FolderMail> trashBox = context.watch<MailsProvider>().trashFolderMail;

    return Scaffold(
      appBar: customAppBar(context, title: "Trash", action: () {
        //
      }),
      body: Column(
        children: [
          Padding(padding: EdgeInsets.only(
           top: AppSize.width(3),
            left: AppSize.width(5),
            right: AppSize.width(5),
            bottom: AppSize.width(3),
          ),
          child: searchComponent(context, trashBox, 'trash'),
          ),
          Expanded(
            child: trashBox.isEmpty ? Center(child: Text("You have no trash mails", style: TextStyle(color: Colors.grey),)) : ListView.builder(
              controller: _scrollController,
              itemCount: trashBox.length + 1, // Add 1 for the loader at the end
              itemBuilder: (context, index) {
                if (index == trashBox.length) {
                  return fetchLoader(isLoading);
                }
                // Display data item
                final item = trashBox[index];
                return SlideInRight(
                  child: Dismissible(
                    key: Key("${item.id}"), // Use a unique key
                    direction: DismissDirection.none, //DismissDirection.endToStart, // Swipe from right to left
                    onDismissed: (direction) {
                      // Call delete function when dismissed
                      // context.read<MailsProvider>().permanentlyDeleteItem(index, 'trash');
                      // ToastUtil().showToast("${item.subject} Permanently Deleted");
                    },
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.symmetric(horizontal: 10.0),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    child: GestureDetector(
                      onTap: () {
                        _showBottomOptions(context, item, index);
                      },
                      child: TrashMailCard(item: item, label: 'TRASH', isTrash: true,)),
                  ),
                );
              },
            ),
          ),
          fetchLoader(isFetching)
        ],
      ),
    );
  }


  void _showBottomOptions(BuildContext context, FolderMail item, int index) {
showModalBottomSheet(
  context: context,
  backgroundColor: Colors.white,
  shape: const RoundedRectangleBorder(
    borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
  ),
  builder: (context) {
    return Container(
      height: 220 + MediaQuery.of(context).padding.bottom, // 👈 Add safe area to your height
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            onTap: () {
              Navigator.of(context).pop();
              context.read<MailsProvider>().permanentlyDeleteItem(index, 'trash');
              ToastUtil().showToast("${item.subject} permanently deleted");
            },
            leading: const Icon(Icons.delete_forever, color: Colors.red),
            title: const Text("Delete Permanently"),
          ),
          ListTile(
            onTap: () {
              Navigator.of(context).pop();
              context.read<MailsProvider>().restore(index, 'trash');
              ToastUtil().showToast("${item.subject} restored");
            },
            leading: const Icon(Icons.restore, color: Colors.green),
            title: const Text("Restore"),
          ),
        ],
      ),
    );
  },
);

}

}