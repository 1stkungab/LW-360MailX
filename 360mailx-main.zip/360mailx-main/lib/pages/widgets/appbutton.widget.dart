
import 'package:flutter/material.dart';

class AppButton extends StatelessWidget {
  final String title;
  final bool isLoading;
  final bool isPrimary;
  final Function()? onPressed;
  const AppButton({
    super.key, this.title='Submit', this.isLoading=false, this.isPrimary=false, this.onPressed
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 18),
        backgroundColor: isPrimary ? Theme.of(context).primaryColor : Theme.of(context).scaffoldBackgroundColor,
        side: BorderSide(width: 1, color: Theme.of(context).primaryColor), // Border properties
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5)
        )
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          isLoading ? const SizedBox(
            height: 15,
            width: 15,
            child: CircularProgressIndicator(
              color: Colors.white,
              strokeWidth: 3,
            ),
          ): Container(),
           SizedBox(width: isLoading ? 7 : 0),
          Text(title, style: TextStyle(color: isPrimary ? Colors.white : null)), // Added text color
        ],
      ),
    );
  }
}
