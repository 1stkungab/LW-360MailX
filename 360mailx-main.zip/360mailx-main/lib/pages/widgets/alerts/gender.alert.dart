
import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/data/gender.data.dart';
import 'package:loveworld_mail/pages/authentication/signup.page.dart';

void showRoundedAlertDialog(BuildContext context,
    {Function(int selectedGender)? onSelectGender, int? initial}) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        buttonPadding: EdgeInsets.zero,
        actionsPadding: const EdgeInsets.only(bottom: 10, right: 10),
        contentPadding: const EdgeInsets.only(left: 15, right: 15, top: 15),
        shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(15), // Adjust border radius as needed
        ),
        content: ValueListenableBuilder<int?>(
            valueListenable: selected,
            builder: (context, _, snapshot) {
              return SizedBox(
                height: AppSize.height(14),
                child: Column(
                  children: [
                    ...List.generate(
                      gender.length,
                      (index) => GestureDetector(
                        onTap: () {
                          if (onSelectGender != null) {
                            onSelectGender(index);
                          }
                          Navigator.of(context)
                              .pop(); // Close dialog after selection
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 10),
                          margin: const EdgeInsets.only(top: 10),
                          decoration: BoxDecoration(
                            border: Border.all(width: 1, color: Colors.grey),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.check_circle_outline,
                                color: selected.value == index
                                    ? AppColors.primary
                                    : Colors.grey,
                              ),
                              const SizedBox(width: 10),
                              Text(gender[index]),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('Cancel'),
          ),
        ],
      );
    },
  );
}
