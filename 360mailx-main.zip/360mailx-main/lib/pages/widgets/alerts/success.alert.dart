import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/pages/authentication/signup.page.dart';

void showSuccess(BuildContext context,
    {Function()? onSelectGender, String? caption}) {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        buttonPadding: EdgeInsets.zero,
        actionsPadding: const EdgeInsets.only(bottom: 10, right: 10),
        contentPadding: const EdgeInsets.only(left: 15, right: 15, top: 15),
        shape: RoundedRectangleBorder(
          borderRadius:
              BorderRadius.circular(15), // Adjust border radius as needed
        ),
        content: ValueListenableBuilder<int?>(
            valueListenable: selected,
            builder: (context, _, snapshot) {
              return SizedBox(
                height: AppSize.height(19),
                child: Column(
                  children: [
                    Lottie.asset(AppAssets.successgreen,
                        width: 145,
                        height: 145,
                        fit: BoxFit.fill,
                        repeat: false),
                    Text(caption ?? "Account Succesfuly Created")
                  ],
                ),
              );
            }),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: const Text('OK'),
          ),
        ],
      );
    },
  );
}
