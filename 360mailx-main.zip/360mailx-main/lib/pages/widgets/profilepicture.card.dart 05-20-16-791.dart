import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/style.config.dart';

class ProfilePictureCard extends StatelessWidget {
  final double? size;
  final bool canroute;
  const ProfilePictureCard({super.key, this.size = 50, this.canroute = true});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: !canroute ? null : () {
      
      },
      child: Container(
        height: size,
        width: size,
        decoration: BoxDecoration(
            color: Colors.black26,
            borderRadius: BorderRadius.circular(100),
           ),
        child: Center(child: Text("U", style: AppTextStyles.header()))
      ),
    );
  }
}
