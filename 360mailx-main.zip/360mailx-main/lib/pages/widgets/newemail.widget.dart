import 'dart:io';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/utilities/preview.file.dart';
import 'package:provider/provider.dart';

void showAnimatedModalSheet(context) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => DraggableScrollableSheet(
      initialChildSize: 0.90,
      maxChildSize: 1.0,
      minChildSize: 0.3,
      builder: (context, scrollController) {

        File? data = context.watch<MailsProvider>().file;


        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).scaffoldBackgroundColor,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
          ),
          child: ListView(
            controller: scrollController,
            children: [
              // Content of the modal sheet
              Padding(
                padding: EdgeInsets.only(
                  left: AppSize.width(5),
                  right: AppSize.width(5),
                  bottom: AppSize.width(5),
                  top: AppSize.width(5),
                ),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                          onTap: () {
                            // subjectController.clear();
                            // toController.clear();
                            // ccController.clear();
                            // bodyController.clear();
                            
                            context.pop();
                          },
                          child: const Icon(Icons.cancel_outlined)),
                       Row(
                        children: [
                           GestureDetector(
                            onTap: (){
                              context.read<MailsProvider>().pickAnyFile();
                            },
                             child: const Icon(
                              Icons.attach_file_outlined,
                                                       ),
                           ),
                          const SizedBox(width: 20),
                          GestureDetector(
                            onTap: (){
                              context.pop();
                              context.read<MailsProvider>().sendMail();
                            },
                            child: const Icon(
                              Icons.send_outlined,
                            ),
                          ),
                          const SizedBox(width: 20),
                          const Icon(
                            Icons.more_vert,
                          ),
                        ],
                      )
                    ]),
              ),

              Padding(
                  padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
                  child: Column(
                    children: [
                      emailfield(controller: toController, title: "To", type: TextInputType.emailAddress),
                      const SizedBox(height: 10),
                      emailfield(controller: ccController, title: "CC", type: TextInputType.emailAddress),
                      const SizedBox(height: 10),
                      emailfield(controller: bccController, title: "BCC", type: TextInputType.emailAddress),
                      const SizedBox(height: 10),
                      emailfield(
                          controller: subjectController, title: "Subject", type: TextInputType.text),
                      const SizedBox(height: 10),

                      TextFormField(
                        minLines: 3, // Minimum height based on line count
                        maxLines: 200, //null, // Allow the field to grow as user types
                        controller: bodyController,
                        decoration: const InputDecoration(
                          isDense: true,
                          border: InputBorder.none, 
                          hintText: "Compose email",
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 12), 
                        ),
                        style: TextStyle(color: Theme.of(context).textTheme.bodyLarge!.color),
                      )
                    ],
                  )),

                  previewFile(data, (){
                    context.read<MailsProvider>().removeUpload();
                  }),
            ],
          ),
        );
      },
    ),
  );
}

emailfield({TextEditingController? controller, required String title, TextInputType? type}) {
  return Container(
    decoration: const BoxDecoration(
      border: Border(
        bottom: BorderSide(color: Colors.grey), // Unified underline color
      ),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: Text(
            title,
          ),
        ),
        Expanded(
          child: TextFormField(
            controller: controller,
            keyboardType: type,
            decoration: const InputDecoration(
              isDense: true,
              border: InputBorder.none, // Remove default underline
              contentPadding: EdgeInsets.symmetric(vertical: 12),
            ),
            style: const TextStyle(),
          ),
        ),
      ],
    ),
  );
}


