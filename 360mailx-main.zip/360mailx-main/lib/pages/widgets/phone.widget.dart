import 'package:flutter/material.dart';
import 'package:loveworld_mail/constant/controller.dart';

class PhoneNumberField extends StatefulWidget {
  final Function(String) onCountryCodeChanged;

  const PhoneNumberField({super.key, required this.onCountryCodeChanged});

  @override
  State<PhoneNumberField> createState() => _PhoneNumberFieldState();
}

class _PhoneNumberFieldState extends State<PhoneNumberField> {
  String selectedCountryCode = '+1'; // Default country code

  final List<Map<String, String>> countries = [
    {'code': '+1', 'flag': '🇺🇸', 'name': 'United States'},
    {'code': '+44', 'flag': '🇬🇧', 'name': 'United Kingdom'},
    {'code': '+91', 'flag': '🇮🇳', 'name': 'India'},
    {'code': '+234', 'flag': '🇳🇬', 'name': 'Nigeria'},
    {'code': '+49', 'flag': '🇩🇪', 'name': 'Germany'},
    {'code': '+61', 'flag': '🇦🇺', 'name': 'Australia'},
    {'code': '+81', 'flag': '🇯🇵', 'name': 'Japan'},
    {'code': '+86', 'flag': '🇨🇳', 'name': 'China'},
    {'code': '+33', 'flag': '🇫🇷', 'name': 'France'},
    {'code': '+39', 'flag': '🇮🇹', 'name': 'Italy'},
    {'code': '+7', 'flag': '🇷🇺', 'name': 'Russia'},
    {'code': '+52', 'flag': '🇲🇽', 'name': 'Mexico'},
    {'code': '+55', 'flag': '🇧🇷', 'name': 'Brazil'},
    {'code': '+27', 'flag': '🇿🇦', 'name': 'South Africa'},
    {'code': '+31', 'flag': '🇳🇱', 'name': 'Netherlands'},
    {'code': '+34', 'flag': '🇪🇸', 'name': 'Spain'},
    {'code': '+47', 'flag': '🇳🇴', 'name': 'Norway'},
    {'code': '+46', 'flag': '🇸🇪', 'name': 'Sweden'},
    {'code': '+41', 'flag': '🇨🇭', 'name': 'Switzerland'},
    {'code': '+48', 'flag': '🇵🇱', 'name': 'Poland'},
    {'code': '+82', 'flag': '🇰🇷', 'name': 'South Korea'},
    {'code': '+60', 'flag': '🇲🇾', 'name': 'Malaysia'},
    {'code': '+66', 'flag': '🇹🇭', 'name': 'Thailand'},
    {'code': '+64', 'flag': '🇳🇿', 'name': 'New Zealand'},
    {'code': '+63', 'flag': '🇵🇭', 'name': 'Philippines'},
    {'code': '+90', 'flag': '🇹🇷', 'name': 'Turkey'},
    {'code': '+30', 'flag': '🇬🇷', 'name': 'Greece'},
    {'code': '+43', 'flag': '🇦🇹', 'name': 'Austria'},
    {'code': '+32', 'flag': '🇧🇪', 'name': 'Belgium'},
    {'code': '+45', 'flag': '🇩🇰', 'name': 'Denmark'},
    {'code': '+420', 'flag': '🇨🇿', 'name': 'Czech Republic'},
    {'code': '+372', 'flag': '🇪🇪', 'name': 'Estonia'},
    {'code': '+358', 'flag': '🇫🇮', 'name': 'Finland'},
    {'code': '+36', 'flag': '🇭🇺', 'name': 'Hungary'},
    {'code': '+353', 'flag': '🇮🇪', 'name': 'Ireland'},
    {'code': '+370', 'flag': '🇱🇹', 'name': 'Lithuania'},
    {'code': '+351', 'flag': '🇵🇹', 'name': 'Portugal'},
    {'code': '+65', 'flag': '🇸🇬', 'name': 'Singapore'},
    {'code': '+421', 'flag': '🇸🇰', 'name': 'Slovakia'},
    {'code': '+46', 'flag': '🇸🇪', 'name': 'Sweden'},
    {'code': '+380', 'flag': '🇺🇦', 'name': 'Ukraine'},
    {'code': '+58', 'flag': '🇻🇪', 'name': 'Venezuela'},
    {'code': '+84', 'flag': '🇻🇳', 'name': 'Vietnam'},
    {'code': '+374', 'flag': '🇦🇲', 'name': 'Armenia'},
    {'code': '+994', 'flag': '🇦🇿', 'name': 'Azerbaijan'},
    {'code': '+375', 'flag': '🇧🇾', 'name': 'Belarus'},
    {'code': '+593', 'flag': '🇪🇨', 'name': 'Ecuador'},
    {'code': '+972', 'flag': '🇮🇱', 'name': 'Israel'},
    {'code': '+212', 'flag': '🇲🇦', 'name': 'Morocco'},
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Country Code Dropdown
        DropdownButton<String>(
          value: selectedCountryCode,
          onChanged: (String? newCode) {
            if (newCode != null) {
              setState(() {
                selectedCountryCode = newCode;
              });
              widget.onCountryCodeChanged(newCode); // Trigger callback
            }
          },
          items: countries.map((country) {
            return DropdownMenuItem<String>(
              value: country['code'],
              child: Row(
                children: [
                  Text(country['flag'] ?? ''),
                  const SizedBox(width: 8),
                  Text(country['code'] ?? ''),
                ],
              ),
            );
          }).toList(),
          underline: Container(),
        ),

        // Phone Number Input Field
        Expanded(
          child: TextFormField(
            controller: phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              hintText: 'Enter phone number',
              border: OutlineInputBorder(),
            ),
          ),
        ),
      ],
    );
  }
}
