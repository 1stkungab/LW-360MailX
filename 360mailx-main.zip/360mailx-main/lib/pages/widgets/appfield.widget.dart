
import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/size.config.dart';

class AppField extends StatelessWidget {
  final Function(String value)? onChange;
    final Function()? onTap;
  final TextEditingController? fieldController;
  final String? label;
  final String? hint;
  final TextInputType? type;
  final int? maxLine;
  final FocusNode? focusNode;
  final String? initial;
  final bool readOnly;
  const AppField({super.key, 
  this.onChange,
  this.onTap,
  this.fieldController,
  this.label="",
  this.hint="",
  this.type = TextInputType.text,
  this.maxLine,
  this.focusNode,
  this.initial,
  this.readOnly  = false,
  });

  @override
  Widget build(BuildContext context) {
    
    final ValueNotifier<bool> visibility = ValueNotifier<bool>(true);

    return ValueListenableBuilder<bool>(
      valueListenable: visibility,
      builder: (context, _, snapshot) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label!),
             SizedBox(height: AppSize.height(1)),
            TextFormField(
              controller: fieldController,
              keyboardType: type,
              maxLines: maxLine,
              initialValue: initial,
              focusNode: focusNode,
              obscureText: label!.contains('Password') ? visibility.value : false,
              decoration: InputDecoration(
                suffixIcon: label!.contains('Password')  ? GestureDetector(
                  onTap: (){
                    visibility.value = !visibility.value;                    },
                  child:  visibility.value ? const Icon(Icons.visibility_outlined, color: Colors.grey) : const Icon(Icons.visibility_off_outlined, color: Colors.grey,),
                ) : null,
                hintText: hint,
                border: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.grey, width: 1),
                  borderRadius: BorderRadius.circular(8), // Adjust border radius as needed
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15), // Adjust padding as needed
              ),

              onChanged: onChange,
              onTap: onTap,
              readOnly: readOnly,
              
            ),
          ],
        );
      }
    );
  }
}
