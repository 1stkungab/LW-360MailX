
import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:loveworld_mail/utilities/showsvg.dart';

class AppBottomNavButton extends StatelessWidget {
  final String image;
  final String title;
  final Function()? onTap;
  final bool active;
  const AppBottomNavButton({
    super.key,
    required this.image,
    required this.title,
    this.active = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: active ?  JelloIn(
        child: Column(
          children: [
             loadSvg(path: image, size: 30, color: active ? Theme.of(context).primaryColor : null),
            const SizedBox(height: 5),
            Text(title, style: TextStyle(color: active ? Theme.of(context).primaryColor : Theme.of(context).textTheme.bodyLarge!.color))
          ],
        ),
      ) : Column(
        children: [
           loadSvg(path: image, size: 30, color: active ? Theme.of(context).primaryColor : null),
          const SizedBox(height: 5),
          Text(title, style: TextStyle(color: active ? Theme.of(context).primaryColor : Theme.of(context).textTheme.bodyLarge!.color))
        ],
      ),
    );
  }
}
