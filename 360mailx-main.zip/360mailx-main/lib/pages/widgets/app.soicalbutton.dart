import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/color.config.dart';

class AppSocialButton extends StatelessWidget {
  final Function()? onTap;
  final String iconImage;
  final bool isLoading;
  final String caption;

  const AppSocialButton({
    super.key,
    required this.iconImage,
    this.onTap,
    this.isLoading = false,
    this.caption = "social",
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 55,
        padding: EdgeInsets.symmetric(
          vertical: 14,
          horizontal: isLoading ? 47 : 5,
        ),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(10),
        ),
        child: isLoading
            ? Center(
                child: CircularProgressIndicator(
                  color: AppColors.primary,
                  strokeWidth: 3,
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(width: 10),
                  Image(image: AssetImage(iconImage)),
                  const SizedBox(width: 10),
                  Text(
                    caption,
                    style: TextStyle(
                      color: Theme.of(context).textTheme.bodyLarge!.color,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(width: 20),
                ],
              ),
      ),
    );
  }
}
