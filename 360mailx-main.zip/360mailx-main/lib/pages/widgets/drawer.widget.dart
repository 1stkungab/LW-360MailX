import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/model/account.model.dart';
import 'package:loveworld_mail/pages/widgets/newemail.widget.dart';
import 'package:loveworld_mail/pages/widgets/profile.icon.card.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/utilities/logger.dart';
import 'package:provider/provider.dart';

class CustomDraw extends StatefulWidget {
  const CustomDraw({
    super.key,
  });

  @override
  State<CustomDraw> createState() => _CustomDrawState();
}

class _CustomDrawState extends State<CustomDraw> {
  @override
  Widget build(BuildContext context) {
    Account? account = context.watch<AuthProvider>().userdata;
    List<dynamic> folders = context.read<MailsProvider>().emailfolders;

    logger.e("Folders: $folders");

    return Drawer(
      // width: AppSize.width(60),
      child: ListView(
        padding: EdgeInsets.only(top: AppSize.height(6)),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                  padding: EdgeInsets.only(
                      left: AppSize.width(5), top: AppSize.height(4)),
                  child: ProfileIconCard()

                  // const ProfilePictureCard(),
                  ),
              Padding(
                padding: EdgeInsets.only(right: AppSize.width(5)),
                child: GestureDetector(
                    onTap: () {
                      context.pop();
                    },
                    child: Icon(
                      Icons.cancel,
                      color: AppColors.primary,
                    )),
              )
            ],
          ),
          Padding(
            padding: EdgeInsets.all(AppSize.width(4)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  account != null
                      ? "${account.fname??""} ${account.lname??""}"
                      : "Anonymous",
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, fontSize: 20),
                ),
                Text(account != null ? account.email ?? "" : "",
                    style: const TextStyle(color: Colors.grey)),
              ],
            ),
          ),
          SizedBox(height: AppSize.height(3)),
          DrawerButton(
            title: "Add another account",
            iconData: Icons.person_add,
            isPrimary: true,
            action: () {
              context.pop();
              context.push(AppRoutes.addaccountpage);
            },
          ),
          DrawerButton(
            title: "Settings & Account",
            iconData: Icons.settings,
            action: () {
              context.pop();
              context.push(AppRoutes.settingpage);
            },
          ),
          DrawerButton(
            title: "Support",
            iconData: Icons.support,
            action: () {
              fromController.text = "solutions@360mailx.com ";
              subjectController.text = "Support Enquiry";
              context.pop();
              showAnimatedModalSheet(context);
            },
          ),
          // DrawerButton(
          //   title: "FAQ",
          //   iconData: Icons.help,
          //   action: () {
          //     context.pop();
          //     context.push(AppRoutes.settingpage);
          //   },
          // ),
          SizedBox(height: AppSize.height(1)),
          // DrawerButton(
          //   title: "Folders",
          //   iconData: Icons.folder,
          //   isPrimary: true,
          //   action: () {},
          // ),
          // ...List.generate(
          //     folders.length,
          //     (index) => Container(
          //         padding: EdgeInsets.symmetric(
          //           horizontal: AppSize.width(13),
          //           vertical: AppSize.width(2.2),
          //         ),
          //         child: Text(folders[index]))),
          SizedBox(
            height: AppSize.height(42),
          ),
          DrawerButton(
            title: "Logout",
            iconData: Icons.logout,
            isPrimary: true,
            color: Colors.red,
            action: () {
              context.read<AuthProvider>().logout(context);
            },
          ),
        ],
      ),
    );
  }
}

class DrawerButton extends StatelessWidget {
  const DrawerButton(
      {super.key,
      required this.title,
      required this.iconData,
      this.action,
      this.isPrimary = false,
      this.color});
  final String title;
  final IconData iconData;
  final Function()? action;
  final bool isPrimary;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: action,
      child: Container(
        margin: EdgeInsets.only(bottom: AppSize.height(1)),
        padding: EdgeInsets.symmetric(
            horizontal: AppSize.width(5), vertical: AppSize.width(2.5)),
        color: isPrimary
            ? color != null
                ? Theme.of(context).drawerTheme.backgroundColor
                : Theme.of(context).primaryColor.withOpacity(0.2)
            : Theme.of(context).drawerTheme.backgroundColor,
        child: Row(
          children: [
            Icon(
              iconData,
              color: isPrimary ? color ?? AppColors.primary : null,
            ),
            const SizedBox(width: 10),
            Text(title,
                style: TextStyle(
                    color: isPrimary ? color ?? AppColors.primary : null)),
          ],
        ),
      ),
    );
  }
}
