import 'package:flutter/material.dart';

class ProfileIconCard extends StatelessWidget {
  const ProfileIconCard({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
          border:
              Border.all(color: Theme.of(context).primaryColor),
          borderRadius: BorderRadius.circular(1000)),
      child: Icon(Icons.person, size: 25, color: Theme.of(context).primaryColor),
    );
  }
}