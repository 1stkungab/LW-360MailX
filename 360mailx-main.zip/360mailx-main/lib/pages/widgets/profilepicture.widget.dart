import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';

class ProfilePictureCard extends StatelessWidget {
  const ProfilePictureCard({
    super.key, this.size = 15
  });
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
    
      width: AppSize.width(size),
      height: AppSize.width(size),
      decoration: BoxDecoration(
        image: DecorationImage(image: AssetImage(AppAssets.miniuser7)),
          shape: BoxShape.circle,
          border: Border.all(width: 1, color: Colors.grey)),
    );
  }
}