import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/utilities/datetime.format.dart';
import 'package:loveworld_mail/utilities/truncate.format.dart';
import 'package:provider/provider.dart';

class MailCard extends StatelessWidget {
  const MailCard({
    super.key,
    required this.item,
    this.isTrash  = false,
  });

  final Map<String, dynamic> item;
  final bool isTrash;

  @override
  Widget build(BuildContext context) {

    List starred =  context.watch<MailsProvider>().starred;
    int isStarred = starred.indexWhere((mail)=> mail['id'] == item['id']);

    return GestureDetector(
      onTap: (){
        context.push(AppRoutes.emaildetailspage);
      },
      child: Container(
        margin: EdgeInsets.only(
          bottom: 15,
          left: AppSize.width(5),
          right: AppSize.width(5),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: Theme.of(context).secondaryHeaderColor,
              child: Text(item['sender']![0], style: const TextStyle(color: Colors.black54),),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item['sender'] ?? "",
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 15)),
                Text(truncateBody(item['title'] ?? "", maxLength: 36),
                    style: const TextStyle(
                        fontWeight: FontWeight.w500, fontSize: 13)),
                Text(
                  truncateBody(item['body'], maxLength: 35),
                  style:
                      const TextStyle(fontWeight: FontWeight.w200, fontSize: 14),
                )
              ],
            ),
            Expanded(child: Container()),
            Column(
              children: [
                Text(formatDateTime(item['date'])),
               isTrash ? const SizedBox() : GestureDetector(
                    onTap: () {
                      context.read<MailsProvider>().starMails(item['id'], 'Trash');
                    },
                    child: isStarred >= 0 ? const Icon(Icons.star, color: Colors.amber) : const Icon(Icons.star_outline))
              ],
            )
          ],
        ),
      ),
    );
  }
}
