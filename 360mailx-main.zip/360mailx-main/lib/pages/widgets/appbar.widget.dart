import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/config/theme.config.dart';
import 'package:loveworld_mail/model/email.model.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:provider/provider.dart';

customAppBar(BuildContext context,
    {String? title = "Inbox", bool isMain=true, Function()? action}) {
  
  List<EmailAccount> account = context.watch<MailsProvider>().emailaccounts;

  return AppBar(
    leadingWidth: AppSize.width(19),
    titleSpacing: AppSize.width(20),
    leading: Padding(
      padding: EdgeInsets.symmetric(
          horizontal: AppSize.width(5)), // Adds padding around the icon
      child: GestureDetector(
        onTap: (){
         isMain ? Scaffold.of(context).openDrawer() : context.pop();
        },
        child:  Icon(
         isMain ? Icons.menu : Icons.arrow_back_ios,
          size:  isMain ? 30 : 28,
        ),
      ),
    ),
    title:  Text(
      account.isEmpty ? "Home" : title ?? "",
      style: TextStyle(color: Theme.of(context).textTheme.bodyLarge!.color),
    ),
    actions: [
      GestureDetector(
          onTap: () {
            AppTheme().switchTheme();
          },
          child: const Icon(
            Icons.brightness_4_outlined,
            size: 30,
          )),

      SizedBox(width: AppSize.width(5))
    ],
  );
}
