import 'package:flutter/material.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/model/foldermail.model.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/utilities/datetime.format.dart';
import 'package:loveworld_mail/utilities/truncate.format.dart';
import 'package:provider/provider.dart';

class TrashMailCard extends StatelessWidget {
  const TrashMailCard({
    super.key,
    required this.item,
    this.isTrash  = false,
    this.label = 'INBOX',
  });

  final FolderMail item;
  final bool isTrash;
  final String label;

  @override
  Widget build(BuildContext context) {

    List<FolderMail> starred =  context.watch<MailsProvider>().staredFolderMail;
    int isStarred = starred.indexWhere((mail)=> mail.id == item.id);

    return Container(
      // color: Colors.amber,
      margin: EdgeInsets.only( bottom: 15, left: AppSize.width(5), right: AppSize.width(5)),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 25,
            backgroundColor: Theme.of(context).secondaryHeaderColor,
            child: Text(label.toLowerCase() == 'sent'?  item.to!.length != 0 ? item.to![0].toUpperCase() : "" : item.from_name![0].toUpperCase(), style: const TextStyle(color: Colors.black54),),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              // color: Colors.green,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Text(item.from ?? "",
                  //     style: const TextStyle(
                  //         fontWeight: FontWeight.w600, fontSize: 15)),
                  Text(truncateBody("${ label == 'SENT'? item.to : item.from_name}" ?? "", maxLength: 36),
                      style: const TextStyle(
                          fontWeight: FontWeight.w500, fontSize: 16)),
                  Text(
                    truncateBody("${item.subject}", maxLength: 35),
                    style:
                        const TextStyle(fontWeight: FontWeight.w200, fontSize: 14),
                  )
                ],
              ),
            ),
          ),
          // Expanded(child: Container()),
          Column(
            children: [
              Text(formatDateTime(item.date)),
             isTrash ? const SizedBox() : GestureDetector(
                  onTap: () {
                    context.read<MailsProvider>().starMails(item.id!, label);
                  },
                  child: isStarred >= 0 ? const Icon(Icons.star, color: Colors.amber) : const Icon(Icons.star_outline))
            ],
          )
        ],
      ),
    );
  }
}
