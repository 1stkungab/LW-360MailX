import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/model/email.model.dart';
import 'package:loveworld_mail/pages/widgets/bottomnav.button.dart';
import 'package:loveworld_mail/pages/widgets/drawer.widget.dart';
import 'package:loveworld_mail/pages/widgets/newemail.widget.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/utilities/logger.dart';
import 'package:provider/provider.dart';

class MainDashboard extends StatefulWidget {
  final StatefulNavigationShell navigationShell;
  const MainDashboard({super.key, required this.navigationShell});

  @override
  State<MainDashboard> createState() => _MainDashboardState();
}

class _MainDashboardState extends State<MainDashboard> {
  final List<Map<String, String>> data = [
    {'title': 'Inbox', 'image': AppAssets.inbox},
    {'title': 'Starred', 'image': AppAssets.starred},
    {'title': 'Sent', 'image': AppAssets.sent},
    {'title': 'Trash', 'image': AppAssets.trash},
  ];

  int titleIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        // Uncomment if needed
        // if (context.read<MailsProvider>().emailaccounts.isEmpty) {
        //   context.go(AppRoutes.firstaddaccountpage);
        // }
      }
    });
  }

  Future<void> refresh() async {
    logger.e("------Refreshing..");
    await context.read<MailsProvider>().fetchEmailAccounts(); // Fetch latest emails
  }

  @override
  Widget build(BuildContext context) {
    List<EmailAccount> account = context.watch<MailsProvider>().emailaccounts;

    return Scaffold(
      drawer: const CustomDraw(),
      body: RefreshIndicator(
        onRefresh: refresh,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: SizedBox(
            height: MediaQuery.of(context).size.height, // Ensures full height
            child: widget.navigationShell,
          ),
        ),
      ),
      bottomNavigationBar: account.isEmpty
          ? null
          : BottomAppBar(
              color: Theme.of(context).scaffoldBackgroundColor,
              surfaceTintColor: Theme.of(context).scaffoldBackgroundColor,
              elevation: 4,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: AppSize.width(3)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(
                    data.length,
                    (index) => AppBottomNavButton(
                      active: index == widget.navigationShell.currentIndex,
                      image: data[index]['image']!,
                      title: data[index]['title']!,
                      onTap: () {
                        widget.navigationShell.goBranch(index,
                            initialLocation:
                                index == widget.navigationShell.currentIndex);
                      },
                    ),
                  ),
                ),
              ),
            ),
      floatingActionButton: account.isEmpty
          ? null
          : FloatingActionButton(
              backgroundColor: Theme.of(context).primaryColor,
              onPressed: () {
                showAnimatedModalSheet(context);
              },
              child: const Icon(Icons.edit, color: Colors.white),
            ),
    );
  }
}
