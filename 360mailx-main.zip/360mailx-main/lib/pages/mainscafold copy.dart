import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/model/email.model.dart';
import 'package:loveworld_mail/pages/widgets/appbar.widget.dart';
import 'package:loveworld_mail/pages/widgets/bottomnav.button.dart';
import 'package:loveworld_mail/pages/widgets/drawer.widget.dart';
import 'package:loveworld_mail/pages/widgets/newemail.widget.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:provider/provider.dart';

class MainDashboard extends StatefulWidget {
  final StatefulNavigationShell navigationShell;
  const MainDashboard({super.key, required this.navigationShell});

  @override
  State<MainDashboard> createState() => _MainDashboardState();
}

class _MainDashboardState extends State<MainDashboard> {

  List<dynamic> data = <dynamic> [
      <String, String>{'title': 'Inbox', 'image': AppAssets.inbox},
      <String, String>{'title': 'Starred', 'image': AppAssets.starred},
      <String, String>{'title': 'Sent', 'image': AppAssets.sent},
      <String, String>{'title': 'Trash', 'image': AppAssets.trash},
    ];

  int titleIndex = 0;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        // if (context.read<MailsProvider>().emailaccounts.length == 0) {
        //   context.go(AppRoutes.firstaddaccountpage);
        // }
      }
    });
  }

  @override
  Widget build(BuildContext context) {

    Future<void> refresh() async {
      await Future.delayed(const Duration(seconds: 2));
      // final appInitializer = AppInitializer(context);
    }

    List<EmailAccount> account = context.watch<MailsProvider>().emailaccounts;

    return Scaffold(
      drawer: const CustomDraw(),
      // appBar: customAppBar(context, title: data[titleIndex]['title'], action: () {}),
      body: RefreshIndicator(onRefresh: refresh, child: widget.navigationShell),
      bottomNavigationBar: account.isEmpty ? null : BottomAppBar(
          color: Theme.of(context).scaffoldBackgroundColor,
          surfaceTintColor: Theme.of(context).scaffoldBackgroundColor,
          elevation: 4,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: AppSize.width(3)),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ...List.generate(
                    data.length,
                    (index) => AppBottomNavButton(
                          active: index == widget.navigationShell.currentIndex,
                          image: data[index]['image'],
                          title: data[index]['title'],
                          onTap: () {
                            widget.navigationShell.goBranch(index, initialLocation: index == widget.navigationShell.currentIndex);
                            // setState(() =>  titleIndex = index );
                          },
                        ))
              ],
            ),
          )),
           floatingActionButton: account.isEmpty ? null : FloatingActionButton(
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () {
          showAnimatedModalSheet(context);
        },
        child: const Icon(Icons.edit, color: Colors.white),
      ),
    );
  }
}
