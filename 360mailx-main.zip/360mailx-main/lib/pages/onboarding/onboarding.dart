import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/constant/data/splash.data.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/storage/app.storage.dart';
import 'package:loveworld_mail/utilities/showsvg.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  int _slideIndex = 0;

  void next(index) {
    if (index < onboaedingdata.length) {
      _slideIndex = index;
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: EdgeInsets.only(
                  top: AppSize.height(0),
                ),
                child:  SizedBox(
              height: 150,
              width: 150,
              child: Image(image: AssetImage(AppAssets.altlogo)),
            ),
              ),
              Expanded(
                  child: PageView.builder(
                      itemCount: onboaedingdata.length,
                      onPageChanged: (index) {
                        next(index);
                      },
                      itemBuilder: (BuildContext context, index) {
                        return Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SlideInDown(
                               duration: const Duration(milliseconds: animationDelay * 4),
                              child: loadSvg(path: onboaedingdata[_slideIndex]['image'], size: AppSize.width(95))),
                             SizedBox(height: AppSize.height(3)),
                            SlideInRight(
                               duration: const Duration(milliseconds: animationDelay * 5),
                              child: Text(
                                onboaedingdata[_slideIndex]['title'],
                                style: TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.w600,
                                    color: Theme.of(context).primaryColor),
                              ),
                            ),
                             SizedBox(height: AppSize.height(1)),
                            SlideInLeft(
                               duration: const Duration(milliseconds: animationDelay *  3),
                              child: Padding(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: AppSize.width(5)),
                                  child: Text(
                                    onboaedingdata[_slideIndex]['description'],
                                    textAlign: TextAlign.center,
                                  )),
                            ),
                          ],
                        );
                      })),
              Padding(
                padding: EdgeInsets.only(
                  left: AppSize.width(8),
                  right: AppSize.width(8),
                  bottom: AppSize.height(4),
                  top: AppSize.height(4),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        ...List.generate(
                            3,
                            (index) => SlideInUp(
                               duration: Duration(milliseconds: animationDelay * index + 1),
                              child: Container(
                                    width: 20,
                                    height: 20,
                                    margin: const EdgeInsets.only(right: 5),
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: _slideIndex >= index
                                            ? AppColors.primary
                                            : Colors.transparent,
                                        border: Border.all(
                                            width: 1, color: AppColors.primary)),
                                  ),
                            ))
                      ],
                    ),
                    GestureDetector(
                        onTap: () async {
                          context.go(AppRoutes.authentication);
                           await AppStorage().updateOnboarded('onboarded');

                        },
                        child: Text(_slideIndex != onboaedingdata.length - 1
                            ? "Skip"
                            : "Next"))
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
