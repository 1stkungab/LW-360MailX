import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/constant/data/userstack.data.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/routing/route.path.dart';

class AuthenticationPage extends StatelessWidget {
  const AuthenticationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: AppSize.height(5)),
                  const Text("WELCOME TO",
                      style:
                          TextStyle(fontSize: 33, fontWeight: FontWeight.w600)),
                  Text(
                    "LOVEWORLD",
                    style: TextStyle(
                        fontSize: 54,
                        height: 0,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primary,
                        letterSpacing: -3),
                  ),
                ],
              ),
              Stack(
                children: [
                  Image(image: AssetImage(AppAssets.auth)),
                  const Positioned(
                      child: Text("MAILS.",
                          style: TextStyle(
                              fontSize: 45, fontWeight: FontWeight.w600))),
                ],
              ),
              SizedBox(height: AppSize.height(4)),
              Row(children: [
                Expanded(
                  flex: 2,
                  child: Container(
                    height: AppSize.height(10),
                    decoration: BoxDecoration(
                        color: Colors.amber,
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            image: AssetImage(AppAssets.smilingman),
                            fit: BoxFit.cover)),
                  ),
                ),
                SizedBox(width: AppSize.width(4)),
                Expanded(
                  child: Container(
                    height: AppSize.height(10),
                    decoration: BoxDecoration(
                        color: Colors.amber,
                        borderRadius: BorderRadius.circular(10),
                        image: DecorationImage(
                            image: AssetImage(AppAssets.smilinglady),
                            fit: BoxFit.cover)),
                  ),
                )
              ]),
              SizedBox(height: AppSize.height(4)),
              Row(
                children: [
                  Expanded(
                      child: AppButton(
                    title: "Login",
                    onPressed: () {
                      context.go(AppRoutes.signinpage);
                    },
                    isPrimary: true,
                  )),
                  SizedBox(width: AppSize.width(10)),
                  Expanded(
                      child: AppButton(
                    title: "Signup",
                    onPressed: () {
                      context.go(AppRoutes.signuppage);
                    },
                  ))
                ],
              ),
              SizedBox(height: AppSize.height(5)),
              SlideInUp(
                duration: const Duration(milliseconds: animationDelay * 2),
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    text: "At ", // First part

                    style: TextStyle(
                      fontSize: 15,
                      color: Theme.of(context).textTheme.bodyLarge!.color,
                    ),
                    children: [
                      TextSpan(
                        text: '360MailX, ',
                        style: TextStyle(
                          color: Theme.of(context).primaryColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      TextSpan(
                        text:
                            "we're redefining your email experience with innovative features designed to streamline your communication and enhance productivity.",
                        style: TextStyle(
                          color: Theme.of(context).textTheme.bodyLarge!.color,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: AppSize.height(5)),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SlideInLeft(
                    duration: const Duration(milliseconds: animationDelay * 4),
                    child: SizedBox(
                      width: 120, // Adjust width as needed
                      height: 40, // Adjust height as needed
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          ...List.generate(
                            userstackdata.length,
                            (index) => Positioned(
                              left: index * 20.0,
                              child: CircleAvatar(
                                radius: 18,
                                backgroundImage:
                                    AssetImage(userstackdata[index]),
                                backgroundColor: AppColors.primary,
                              ),
                            ),
                          ),
                          Positioned(
                            left: (userstackdata.length) * 20.0,
                            child: const CircleAvatar(
                              radius: 18,
                              backgroundColor: Color(0xFF00BFFF),
                              child: Icon(
                                Icons.add,
                                color: Colors.white,
                                size: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SlideInRight(
                    duration: const Duration(milliseconds: animationDelay * 4),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            ...List.generate(
                                5,
                                (index) => const Icon(Icons.star,
                                    size: 15, color: Color(0xFF00BFFF)))
                          ],
                        ),
                        const Text(
                          "10,000+ Users",
                          style: TextStyle(
                              fontSize: 13, fontWeight: FontWeight.w600),
                        )
                      ],
                    ),
                  )
                ],
              )
            
            ],
          ),
        ),
      ),
    );
  }
}
