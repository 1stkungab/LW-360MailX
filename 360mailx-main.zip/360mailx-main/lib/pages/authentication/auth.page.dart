import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/constant/data/userstack.data.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/routing/route.path.dart';

class AuthenticationPage extends StatelessWidget {
  const AuthenticationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
        Positioned(
  top: -20,
  child: Container(
    width: MediaQuery.of(context).size.width,
    height: AppSize.height(75),
    decoration: BoxDecoration(
      // color: Colors.blue,
      image: DecorationImage(
        image: AssetImage(AppAssets.banner3),
        fit: BoxFit.cover,
      ),
    ),
    child: Container(
      padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage("assets/banners/test2.png"),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(
            const Color(0xff001120).withOpacity(0.9), // Adjust color & opacity as needed
            BlendMode.darken,             // Choose a BlendMode (e.g., darken, overlay)
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              SizedBox(height: AppSize.height(10)),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SlideInRight(
                    child: Text(
                      "Welcome to 360MailX",
                      style: TextStyle(
                        color: Theme.of(context).scaffoldBackgroundColor,
                        fontWeight: FontWeight.w600,
                        fontSize: 22,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SlideInDown(
                duration: const Duration(milliseconds: animationDelay * 4),
                child: Text(
                  "Let's upgrade your mailing experience!",
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontSize: 30,
                    color: Theme.of(context).scaffoldBackgroundColor,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SlideInDown(
                duration: const Duration(milliseconds: animationDelay * 6),
                child: Text(
                  "One app, all your emails, perfectly organized. Simplify your inbox experience and enjoy a unified view of every message!",
                  style: TextStyle(
                    color: Theme.of(context).scaffoldBackgroundColor,
                  ),
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: AppSize.height(20)),
            ],
          ),
        ],
      ),
    ),
  ),
),

          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.only(
                  left: AppSize.width(5),
                  right: AppSize.width(5),
                  top: AppSize.width(6)),
              height: AppSize.height(45),
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(30),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // SizedBox(height: AppSize.height(2)),
                  Row(
                    children: [
                      Expanded(
                          child: AppButton(
                        title: "Login",
                        onPressed: () {
                          context.push(AppRoutes.signinpage);
                        },
                        isPrimary: true,
                      )),
                      SizedBox(width: AppSize.width(10)),
                      Expanded(
                          child: AppButton(
                        title: "Signup",
                        onPressed: () {
                          context.push(AppRoutes.signuppage);
                        },
                      ))
                    ],
                  ),
                  SizedBox(height: AppSize.height(5)),
                  SlideInUp(
                    duration: const Duration(milliseconds: animationDelay * 2),
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        text: "At ", // First part

                        style: TextStyle(
                          fontSize: 15,
                          color: Theme.of(context).textTheme.bodyLarge!.color,
                        ),
                        children: [
                          TextSpan(
                            text: '360MailX, ',
                            style: TextStyle(
                              color: Theme.of(context).primaryColor,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          TextSpan(
                            text:
                                "we're redefining your email experience with innovative features designed to streamline your communication and enhance productivity.",
                            style: TextStyle(
                              color:
                                  Theme.of(context).textTheme.bodyLarge!.color,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: AppSize.height(5)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SlideInLeft(
                        duration:
                            const Duration(milliseconds: animationDelay * 4),
                        child: SizedBox(
                          width: 120, // Adjust width as needed
                          height: 40, // Adjust height as needed
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              ...List.generate(
                                userstackdata.length,
                                (index) => Positioned(
                                  left: index * 20.0,
                                  child: CircleAvatar(
                                    radius: 18,
                                    backgroundImage:
                                        AssetImage(userstackdata[index]),
                                    backgroundColor: AppColors.primary,
                                  ),
                                ),
                              ),
                              Positioned(
                                left: (userstackdata.length) * 20.0,
                                child: const CircleAvatar(
                                  radius: 18,
                                  backgroundColor: Color(0xFF00BFFF),
                                  child: Icon(
                                    Icons.add,
                                    color: Colors.white,
                                    size: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SlideInRight(
                        duration:
                            const Duration(milliseconds: animationDelay * 4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                ...List.generate(
                                    5,
                                    (index) => const Icon(Icons.star,
                                        size: 15, color: Color(0xFF00BFFF)))
                              ],
                            ),
                            const Text(
                              "10,000+ Users",
                              style: TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w600),
                            )
                          ],
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
