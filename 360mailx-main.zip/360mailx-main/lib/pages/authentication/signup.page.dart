import 'package:animate_do/animate_do.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/constant/data/gender.data.dart';
import 'package:loveworld_mail/constant/otpstate.dart';
import 'package:loveworld_mail/helper/validator.field.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/pages/widgets/alerts/gender.alert.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/pages/widgets/appfield.widget.dart';
import 'package:loveworld_mail/provider/app.provider.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:provider/provider.dart';

ValueNotifier<int?> selected = ValueNotifier<int?>(null);

class SignupPage extends StatelessWidget {
  const SignupPage({super.key});

  @override
  Widget build(BuildContext context) {
    ValueNotifier<bool> isLoading = ValueNotifier<bool>(false);

    Future<void> selectDate(
        BuildContext context, TextEditingController controller) async {
      final DateTime? picked = await showDatePicker(
        context: context,
        initialDate: DateTime(2015),
        firstDate: DateTime(1901),
        lastDate: DateTime(2015),
      );
      if (picked != null) {
        controller.text = "${picked.toLocal()}".split(' ')[0];
      }
    }

    bool signupVerified(payload) {
      String? emailError = Validator.validateEmail(payload['email']);
      String? passwordError = Validator.validatePassword(payload['password']);
      String? firstnameError = Validator.validateName(payload['fname']);
      String? lastnameError = Validator.validateName(payload['lname']);
      String? phoneError = Validator.validatePhone(payload['phone']);

      if (emailError != null) {
        locator<ToastService>().showToast(emailError);
        return false;
      }

      if (passwordError != null) {
        locator<ToastService>().showToast(passwordError);
        return false;
      }

      if (phoneError != null) {
        locator<ToastService>().showToast(phoneError);
        return false;
      }

      if (firstnameError != null || lastnameError != null) {
        locator<ToastService>().showToast('Name cannot be empty');
        return false;
      }
      return true;
    }

    return Scaffold(
      body: SingleChildScrollView(

        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              Positioned(
                top: -20,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: AppSize.height(35),
                  padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      image: DecorationImage(
                          image: AssetImage(AppAssets.banner3), fit: BoxFit.cover)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: AppSize.height(15)),
                      SlideInRight(
                        duration: const Duration(milliseconds: animationDelay * 4),
                        child: Text(
                          "Getting Started",
                          textAlign: TextAlign.end,
                          style: TextStyle(
                              fontSize: 30,
                              color: Theme.of(context).scaffoldBackgroundColor,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0),
                        ),
                      ),
                      const SizedBox(height: 2),
                      SlideInRight(
                        duration: const Duration(milliseconds: animationDelay * 6),
                        child: Text(
                          "To stay connected, kindly sign up with your valid credentials",
                          style: TextStyle(
                              color: Theme.of(context).scaffoldBackgroundColor),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: EdgeInsets.only(
                      left: AppSize.width(5),
                      right: AppSize.width(5),
                      top: AppSize.width(6)),
                  height: AppSize.height(75),
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: AppField(
                                fieldController: firstnameController,
                                label: "Firstname",
                                hint: "Enter firstname",
                                type: TextInputType.visiblePassword,
                                maxLine: 1,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: AppField(
                                fieldController: lastnameController,
                                label: "Lastname",
                                hint: "Enter lastname",
                                type: TextInputType.visiblePassword,
                                maxLine: 1,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: AppSize.height(2)),
                        AppField(
                          fieldController: emailController,
                          label: "Email",
                          hint: "Enter email",
                          type: TextInputType.emailAddress,
                        ),
                        SizedBox(height: AppSize.height(2)),
                         AppField(
                          fieldController: phoneController,
                          label: "Phone",
                          hint: "Enter phons",
                          type: TextInputType.name,
                        ),
                        SizedBox(height: AppSize.height(2)),
                        AppField(
                          fieldController: passwordController,
                          label: "Password",
                          hint: "Enter password",
                          type: TextInputType.visiblePassword,
                          maxLine: 1,
                        ),
                        SizedBox(height: AppSize.height(2)),
                        Row(
                          children: [
                            Expanded(
                              child: AppField(
                                fieldController: startDateController,
                                label: "DOB",
                                hint: "Date of Birth",
                                type: TextInputType.number,
                                readOnly: true,
                                onTap: () {
                                  selectDate(context, startDateController);
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: AppField(
                                fieldController: genderController,
                                label: "Gender",
                                hint: "Gender",
                                readOnly: true,
                                onTap: () {
                                  showRoundedAlertDialog(
                                    context,
                                    onSelectGender: (selectedGender) {
                                      genderController.text = gender[selectedGender];
                                      selected.value = selectedGender;
                                    },
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: AppSize.height(5)),
                    
                        ValueListenableBuilder<bool>(
                            valueListenable: isLoading,
                            builder: (context, _, snapshot) {
                              return AppButton(
                                  isPrimary: true,
                                  isLoading: isLoading.value,
                                  title: "Sign Up",
                                  onPressed: () async {

                                    context.read<AppProvider>().setOTPState(OTPSTATEENUM.REGISTER);
                         
                                    Map<String, dynamic> payload = {
                                      "uuid": "111111",
                                      "auth_type": "email",
                                      "fname": firstnameController.text,
                                      "lname": lastnameController.text,
                                      "email": emailController.text,
                                      "phone" : phoneController.text,
                                      "password": passwordController.text,
                                      "password_confirmation":
                                          passwordController.text,
                                      "dob": startDateController.text,
                                      "country": "Nigeria",
                                      "gender": genderController.text
                                    };
                    
                                    if (signupVerified(payload)) {
                                      isLoading.value = true;
          
                                      await context.read<AuthProvider>().requestOTP().then((completed){
                                        locator<GoRouter>().push(AppRoutes.otppage);
                                      });
                                   
                                    // await context.read<AuthProvider>().signup(payload, context).then((completed) async{
                                    //   if(completed){
                                    //     final appInitializer = AppInitializer(context);
                                    //     await appInitializer.loadAppData();
                                    //     locator<ToastService>().showToast('Signup Succesful');
                                    //     locator<GoRouter>().go(AppRoutes.inboxpage);
                                    //   }
          
                                    //   });
          
                                      isLoading.value = false;
                                    }
                                  });
                            }),
                    
                        SizedBox(height: AppSize.height(5)),
                        FadeInUp(
                          duration: const Duration(milliseconds: animationDelay * 6),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              RichText(
                                textAlign: TextAlign.center,
                                text: TextSpan(
                                  text: "Already have an account? ",
                                  style: const TextStyle(color: Colors.black),
                                  children: [
                                    TextSpan(
                                      text: 'Sign in',
                                      style: const TextStyle(
                                        color: Colors
                                            .blue, // Customize color for "Sign up" text
                                        fontWeight: FontWeight.bold,
                                      ),
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          context.go(AppRoutes.signinpage);
                                        },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: AppSize.height(3)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
