import 'package:animate_do/animate_do.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/app.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/constant/otpstate.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/provider/app.provider.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:provider/provider.dart';

class OTPPage extends StatefulWidget {
  const OTPPage({super.key});

  @override
  State<OTPPage> createState() => _OTPPageState();
}

class _OTPPageState extends State<OTPPage> {
  bool processing = false;

  void loading() {
    setState(() {
      processing = !processing;
    });
  }

  @override
  Widget build(BuildContext context) {
    int count = 6;

    final List<FocusNode> focusNodes = List.generate(6, (index) => FocusNode());

    return Scaffold(
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              Positioned(
                top: -20,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: AppSize.height(35),
                  padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      image: DecorationImage(
                          image: AssetImage(AppAssets.banner3),
                          fit: BoxFit.cover)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: AppSize.height(15)),
                      SlideInRight(
                        duration:
                            const Duration(milliseconds: animationDelay * 4),
                        child: Text(
                          "Enter OTP!",
                          textAlign: TextAlign.end,
                          style: TextStyle(
                              fontSize: 30,
                              color: Theme.of(context).scaffoldBackgroundColor,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0),
                        ),
                      ),
                      const SizedBox(height: 2),
                      SlideInRight(
                        duration:
                            const Duration(milliseconds: animationDelay * 6),
                        child: Text(
                          "An OTP has has been sent to ${emailController.text}. kindly enter to verify your email",
                          style: TextStyle(
                              color: Theme.of(context).scaffoldBackgroundColor),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: EdgeInsets.only(
                      left: AppSize.width(5),
                      right: AppSize.width(5),
                      top: AppSize.width(6)),
                  height: AppSize.height(75),
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: AppSize.height(1)),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: List.generate(
                          count,
                          (index) => SlideInUp(
                            duration: Duration(
                                milliseconds: animationDelay * index + 3),
                            child: SizedBox(
                              width:
                                  AppSize.width(13), // Adjust width as needed
                              child: TextFormField(
                                controller: controllers[index],
                                focusNode: focusNodes[index],
                                keyboardType: TextInputType.number,
                                textAlign: TextAlign.center,
                                maxLength: 1,
                                decoration: const InputDecoration(
                                    border: OutlineInputBorder(),
                                    contentPadding:
                                        EdgeInsets.symmetric(vertical: 16),
                                    counter: Text("")),
                                onChanged: (value) {
                                  if (value.length == 1 &&
                                      index < focusNodes.length - 1) {
                                    focusNodes[index].unfocus();
                                    FocusScope.of(context)
                                        .requestFocus(focusNodes[index + 1]);
                                  } else if (value.isEmpty && index > 0) {
                                    focusNodes[index].unfocus();
                                    FocusScope.of(context)
                                        .requestFocus(focusNodes[index - 1]);
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                      ),
                      controllers
                              .map((controller) => controller.text)
                              .join()
                              .isEmpty
                          ? FadeInUp(
                              duration: const Duration(
                                  milliseconds: animationDelay * 4),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  RichText(
                                    textAlign: TextAlign.center,
                                    text: TextSpan(
                                      text: "I didn't receive code ",
                                      style:
                                          const TextStyle(color: Colors.black),
                                      children: [
                                        TextSpan(
                                          text: 'Resend',
                                          style: const TextStyle(
                                            color: Colors
                                                .blue, // Customize color for "Sign up" text
                                            fontWeight: FontWeight.bold,
                                          ),
                                          recognizer: TapGestureRecognizer()
                                            ..onTap = () {
                                              //RESEND Todo
                                              // context.push(AppRoutes.phonepage);
                                              context
                                                  .read<AuthProvider>()
                                                  .requestOTP()
                                                  .then((completed) {
                                                if (completed) {
                                                  locator<ToastService>()
                                                      .showToast("OTP resent");
                                                }
                                              });
                                            },
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Container(),
                      SizedBox(height: AppSize.height(10)),
                      AppButton(
                        title: "Verify",
                        isLoading: processing,
                        onPressed: () async {
                          if (context.read<AppProvider>().otpState ==
                              OTPSTATEENUM.CHANGEPASSWORD) {
                            context.push(AppRoutes.changepassword);
                          } else {
                            loading();

                            String otp = controllers
                                .map((controller) => controller.text)
                                .join();
                            Map<String, dynamic> otppayload = {
                              "email": emailController.text,
                              'otp': otp
                            };

                            context
                                .read<AuthProvider>()
                                .verifyEmailOTP(otppayload)
                                .then((otpverified) async {
                              print("verified $otpverified");

                              if (otpverified) {
                                Map<String, dynamic> payload = {
                                  "uuid": "111111",
                                  "auth_type": "email",
                                  "fname": firstnameController.text,
                                  "lname": lastnameController.text,
                                  "email": emailController.text,
                                  "phone": phoneController.text,
                                  "password": passwordController.text,
                                  "password_confirmation":
                                      passwordController.text,
                                  "dob": startDateController.text,
                                  "country": "Nigeria",
                                  "gender": genderController.text
                                };
                                await context
                                    .read<AuthProvider>()
                                    .signup(payload, context)
                                    .then((completed) async {
                                  if (completed) {
                                    final appInitializer =
                                        AppInitializer(context);
                                    await appInitializer.loadAppData();
                                    locator<ToastService>()
                                        .showToast('Signup Succesful');
                                    locator<GoRouter>().go(AppRoutes.inboxpage);
                                  }

                                });
                              }

                              loading();
                            });

                            //  showSuccess(context);
                          }
                        },
                        isPrimary: true,
                      ),
                      Expanded(child: SizedBox(height: AppSize.height(3))),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("Remember password? "),
                          GestureDetector(
                            onTap: () {
                              context.push(AppRoutes.signinpage);
                            },
                            child: Text(
                              "Login",
                              style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.primary),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: AppSize.height(5)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
