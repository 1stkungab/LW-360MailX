import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/pages/widgets/phone.widget.dart';
import 'package:loveworld_mail/routing/route.path.dart';

class PhonePage extends StatefulWidget {
  const PhonePage({super.key});

  @override
  State<PhonePage> createState() => _PhonePageState();
}

class _PhonePageState extends State<PhonePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
              Positioned(
            top: -20,
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: AppSize.height(35),
              padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
              decoration: BoxDecoration(
                  color: Colors.blue,
                  image: DecorationImage(
                      image: AssetImage(AppAssets.banner3), fit: BoxFit.cover)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: AppSize.height(15)),
                  SlideInRight(
                    duration: const Duration(milliseconds: animationDelay * 4),
                    child: Text(
                      "Enter Phone",
                      textAlign: TextAlign.end,
                      style: TextStyle(
                          fontSize: 30,
                          color: Theme.of(context).scaffoldBackgroundColor,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0),
                    ),
                  ),
                  const SizedBox(height: 2),
                  SlideInRight(
                    duration: const Duration(milliseconds: animationDelay * 6),
                    child: Text(
                      "A valid phone number is required to complete the verification process.",
                      style: TextStyle(color: Theme.of(context).scaffoldBackgroundColor),
                      textAlign: TextAlign.left,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: EdgeInsets.only(
                  left: AppSize.width(5),
                  right: AppSize.width(5),
                  top: AppSize.width(6)),
              height: AppSize.height(75),
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(30),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
           
                  SizedBox(height: AppSize.height(1)),
                  PhoneNumberField(onCountryCodeChanged: (data) {
                  }),

                  SizedBox(height: AppSize.height(10)),
                  AppButton(
                    title: "Verify",
                    onPressed: () {
                      context.push(AppRoutes.otppage);
                    },
                    isPrimary: true,
                  ),
                  Expanded(child: SizedBox(height: AppSize.height(3))),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Remember password? "),
                      GestureDetector(
                        onTap: () {
                          context.push(AppRoutes.signinpage);
                        },
                        child: Text(
                          "Login",
                          style: TextStyle(
                              fontWeight: FontWeight.w600,
                              color: AppColors.primary),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: AppSize.height(5)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
