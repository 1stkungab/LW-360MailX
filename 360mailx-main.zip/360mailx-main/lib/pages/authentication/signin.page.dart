import 'dart:math';

import 'package:animate_do/animate_do.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/app.dart';
import 'package:loveworld_mail/config/color.config.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/helper/validator.field.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/pages/dashboard/kingschat.webview.page.dart';
import 'package:loveworld_mail/pages/widgets/app.soicalbutton.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/pages/widgets/appfield.widget.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:provider/provider.dart';

class SigninPage extends StatelessWidget {
  const SigninPage({super.key});

  @override
  Widget build(BuildContext context) {
    double checkbox = 20;
    ValueNotifier<bool> isLoading = ValueNotifier<bool>(false);
    ValueNotifier<bool> remeberme = ValueNotifier<bool>(false);

    bool verifyFields(payload) {
      String? emailError = Validator.validateEmail(payload['email']);
      String? passwordError = Validator.validatePassword(payload['password']);
      if (emailError != null) {
        locator<ToastService>().showToast(emailError);
        return false;
      }

      if (passwordError != null) {
        locator<ToastService>().showToast(passwordError);
        return false;
      }
      return true;
    }



    String generateRandomDeviceId() {
      const String chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      Random random = Random();
      return List.generate(16, (index) => chars[random.nextInt(chars.length)]).join();
    }

    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              Positioned(
                top: -20,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: AppSize.height(35),
                  padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      image: DecorationImage(
                          image: AssetImage(AppAssets.banner3),
                          fit: BoxFit.cover)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: AppSize.height(15)),
                      SlideInRight(
                        duration:
                            const Duration(milliseconds: animationDelay * 4),
                        child: Text(
                          "Welcome back!",
                          textAlign: TextAlign.end,
                          style: TextStyle(
                              fontSize: 30,
                              color: Theme.of(context).scaffoldBackgroundColor,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0),
                        ),
                      ),
                      const SizedBox(height: 2),
                      SlideInRight(
                        duration:
                            const Duration(milliseconds: animationDelay * 6),
                        child: Text(
                          "To stay connected, kindly sign in with your valid credentials",
                          // "Sign into your Account",
                          style: TextStyle(
                              color: Theme.of(context).scaffoldBackgroundColor),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: EdgeInsets.only(
                      left: AppSize.width(5),
                      right: AppSize.width(5),
                      top: AppSize.width(6)),
                  height: AppSize.height(75),
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: AppSize.height(0)),
                      AppField(
                        fieldController: emailController,
                        label: "Email",
                        hint: "Enter email",
                        type: TextInputType.emailAddress,
                      ),
                      SizedBox(height: AppSize.height(2)),
                      AppField(
                        fieldController: passwordController,
                        label: "Password",
                        hint: "Enter password",
                        type: TextInputType.visiblePassword,
                        maxLine: 1,
                      ),
                      SizedBox(height: AppSize.height(3)),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              ValueListenableBuilder<bool>(
                                  valueListenable: remeberme,
                                  builder: (context, _, snapshot) {
                                    return GestureDetector(
                                      onTap: () {
                                        remeberme.value = !remeberme.value;
                                      },
                                      child: Container(
                                        width: checkbox,
                                        height: checkbox,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                            border: Border.all(
                                                width: 1,
                                                color: AppColors.primary)),
                                        child: remeberme.value
                                            ? Container(
                                                width: checkbox,
                                                height: checkbox,
                                                margin: const EdgeInsets.all(2),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            5),
                                                    color: AppColors.primary),
                                              )
                                            : null,
                                      ),
                                    );
                                  }),
                              const SizedBox(
                                width: 10,
                              ),
                              const Text(
                                "Remember Me",
                                style: TextStyle(color: Colors.grey),
                              )
                            ],
                          ),
                          GestureDetector(
                            onTap: () {
                              context.push(AppRoutes.verifyemail);
                            },
                            child: Text(
                              "Forgot Password?",
                              style: TextStyle(
                                  color: AppColors.primary,
                                  fontWeight: FontWeight.w600),
                            ),
                          )
                        ],
                      ),
                      SizedBox(height: AppSize.height(5)),
                      ValueListenableBuilder<bool>(
                          valueListenable: isLoading,
                          builder: (context, _, snapshot) {
                            return AppButton(
                                isPrimary: true,
                                isLoading: isLoading.value,
                                title: "Sign In",
                                onPressed: () async {
                                  Map<String, dynamic> payload = {
                                    "email": emailController.text,
                                    "password": passwordController.text
                                  };

                                  if (verifyFields(payload)) {
                                    isLoading.value = true;

                                    await context
                                        .read<AuthProvider>()
                                        .signin(payload, context)
                                        .then((completed) async {
                                      if (completed) {
                                        final appInitializer =
                                            AppInitializer(context);
                                        await appInitializer.loadAppData();
                                        locator<ToastService>()
                                            .showToast("Login Succesful");
                                        locator<GoRouter>()
                                            .go(AppRoutes.inboxpage);
                                      }
                                    });

                                    isLoading.value = false;
                                  }
                                });
                          }),
                      SizedBox(height: AppSize.height(3)),
                      Stack(
                        children: [
                          const Divider(),
                          Align(
                            child: Container(
                              color: Theme.of(context).scaffoldBackgroundColor,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 15,
                              ),
                              child: const Text(
                                "Or Continue with",
                                style: TextStyle(fontWeight: FontWeight.w500),
                              ),
                            ),
                          )
                        ],
                      ),
                      SizedBox(height: AppSize.height(3)),
                      FadeInUp(
                        duration:
                            const Duration(milliseconds: animationDelay * 6),
                        child: Row(
                          children: [
                            Expanded(
                              child: AppSocialButton(
                                iconImage: AppAssets.kingschat,
                                caption: "Sign in with Kingschat",
                                onTap: () {
                                  // locator<GoRouter>()
                                  //     .push(AppRoutes.kingschatlogin);

                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => KingsChatLogin(
                                        randomDeviceId: generateRandomDeviceId(),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: AppSize.height(5)),
                      FadeInUp(
                        duration:
                            const Duration(milliseconds: animationDelay * 4),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                text: "Don't have an account? ",
                                style: const TextStyle(color: Colors.black),
                                children: [
                                  TextSpan(
                                    text: 'Sign up',
                                    style: const TextStyle(
                                      color: Colors
                                          .blue, // Customize color for "Sign up" text
                                      fontWeight: FontWeight.bold,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        context.go(AppRoutes.signuppage);
                                      },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: AppSize.height(3)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


