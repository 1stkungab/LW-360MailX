import 'package:animate_do/animate_do.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:loveworld_mail/config/size.config.dart';
import 'package:loveworld_mail/constant/asset.path.dart';
import 'package:loveworld_mail/constant/controller.dart';
import 'package:loveworld_mail/constant/data/animation.data.dart';
import 'package:loveworld_mail/constant/otpstate.dart';
import 'package:loveworld_mail/helper/validator.field.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/pages/widgets/appbutton.widget.dart';
import 'package:loveworld_mail/pages/widgets/appfield.widget.dart';
import 'package:loveworld_mail/provider/app.provider.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/routing/route.path.dart';
import 'package:loveworld_mail/services/toast.service.dart';
import 'package:provider/provider.dart';

class EmailVerification extends StatelessWidget {
  const EmailVerification({super.key});

  @override
  Widget build(BuildContext context) {

    ValueNotifier<bool> isLoading = ValueNotifier<bool>(false);

    bool verifyFields(payload) {
      String? emailError = Validator.validateEmail(payload['email']);
      if (emailError != null) {
        locator<ToastService>().showToast(emailError);
        return false;
      }
      return true;
    }

    return Scaffold(
      body: SingleChildScrollView(
        child: SizedBox(
            height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              Positioned(
                top: -20,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: AppSize.height(35),
                  padding: EdgeInsets.symmetric(horizontal: AppSize.width(5)),
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      image: DecorationImage(
                          image: AssetImage(AppAssets.banner3), fit: BoxFit.cover)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: AppSize.height(15)),
                      SlideInRight(
                        duration: const Duration(milliseconds: animationDelay * 4),
                        child: Text(
                          "Forgot Password",
                          textAlign: TextAlign.end,
                          style: TextStyle(
                              fontSize: 30,
                              color: Theme.of(context).scaffoldBackgroundColor,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0),
                        ),
                      ),
                      const SizedBox(height: 2),
                      SlideInRight(
                        duration: const Duration(milliseconds: animationDelay * 6),
                        child: Text(
                          "Enter your email account to reset password",
                          // "Sign into your Account",
                          style: TextStyle(color: Theme.of(context).scaffoldBackgroundColor),
                          textAlign: TextAlign.left,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: EdgeInsets.only(
                      left: AppSize.width(5),
                      right: AppSize.width(5),
                      top: AppSize.width(6)),
                  height: AppSize.height(75),
                  decoration: BoxDecoration(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: AppSize.height(0)),
                      AppField(
                        fieldController: emailController,
                        label: "Email",
                        hint: "Enter email",
                        type: TextInputType.emailAddress,
                      ),
                      SizedBox(height: AppSize.height(2)),
             
                      SizedBox(height: AppSize.height(5)),
       
                                        ValueListenableBuilder<bool>(
                          valueListenable: isLoading,
                          builder: (context, _, snapshot) {
                            return AppButton(
                                isPrimary: true,
                                isLoading: isLoading.value,
                                title: "Continue",
                                onPressed: () async {
                                  Map<String, dynamic> payload = {"email": emailController.text};
          
                                  if (verifyFields(payload)) {
                                    isLoading.value = true;
                                    context.read<AppProvider>().setOTPState(OTPSTATEENUM.CHANGEPASSWORD);
                                     await context.read<AuthProvider>().forgetPassword(payload).then((completed) async {
                                      if (completed) {
                                        context.push(AppRoutes.signinpage);

                                        // context.push(AppRoutes.otppage);
                                        // final appInitializer = AppInitializer(context);
                                        // await appInitializer.loadAppData();
                                        // locator<ToastService>().showToast("Login Succesful");
                                        // locator<GoRouter>().go(AppRoutes.inboxpage);
                                      }
                                     });
                                  
                                    isLoading.value = false;
                                  }
                                });
                          }),
                      SizedBox(height: AppSize.height(5)),
                      FadeInUp(
                        duration: const Duration(milliseconds: animationDelay * 4),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RichText(
                              textAlign: TextAlign.center,
                              text: TextSpan(
                                text: "Remeber your password? ",
                                style: const TextStyle(color: Colors.black),
                                children: [
                                  TextSpan(
                                    text: 'Sign in',
                                    style: const TextStyle(
                                      color: Colors
                                          .blue, // Customize color for "Sign up" text
                                      fontWeight: FontWeight.bold,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        context.go(AppRoutes.signinpage);
                                      },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: AppSize.height(3)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
