import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:loveworld_mail/config/router.config.dart';
import 'package:loveworld_mail/locator.dart';
import 'package:loveworld_mail/provider/app.provider.dart';
import 'package:loveworld_mail/provider/auth.provider.dart';
import 'package:loveworld_mail/provider/mails.provider.dart';
import 'package:loveworld_mail/provider/theme.provider.dart';
import 'package:loveworld_mail/routing/navigator_1.0.dart';
import 'package:provider/provider.dart';

void main() async {
  
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: ".env");
  await Firebase.initializeApp();
  // try {
  //   await dotenv.load();
  // } catch (e) {
  //   print("Failed to load .env file: $e");
  // }

  setupLocator();
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(create: (_) => MailsProvider()),
    ChangeNotifierProvider(create: (_) => AppProvider()),
    ChangeNotifierProvider(create: (_) => AuthProvider()),
  ], child: const MyApp()));

}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
        valueListenable: ThemeClass.themeNotifier,
        builder: (_, ThemeMode currentMode, __) {
          return MaterialApp.router(
              debugShowCheckedModeBanner: false,
              title: 'My Devotional Book',
              themeMode: currentMode,
              theme: ThemeClass.lightTheme,
              scaffoldMessengerKey: AppNavigatorKeys.instance.scaffoldKey, //locator<ToastService>().scaffoldMessengerKey,
              darkTheme: ThemeClass.darkTheme,
              routerConfig: AppRouter().router);
        });
  }
}


class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[],
        ),
      ),
    );
  }
}
